# Screening Report v1

Project: AM-AUTO-20260918-R1  
Date: 2026-09-18  
Research direction: Agent Memory

## 1. Outcome

Initial candidate pool: 18  
Killed by prior-art / overlap audit: 14  
Reserve: 1  
Survived current Gate: 3

Survivors:
1. C15 Budgeted Memory Recertification Scheduler
2. C16 Version-Bound Verifier Certificates
3. C17 Maintenance-Aware Memory Admission

## 2. Screening layers completed

### Layer A: Landscape saturation scan
Mapped crowded 2026 regions including prospective memory, causal memory, retrieval utilization, fixation, consolidation, trustworthy writes, staleness/rollback, contextual scope, uncertainty, procedural memory, tool drift, authority laundering and model-upgrade migration.

### Layer B: Candidate prior-art audit
Every candidate was compared against direct neighbors. Fourteen were killed rather than renamed.

### Layer C: Reverse novelty search
For the three survivors, search queries were written specifically to find papers that would invalidate the Idea. C15 found a very close precursor and was narrowed. C16/C17 exact-term searches found adjacent but not directly equivalent work by the cutoff.

### Layer D: Operationalization fixture
Each survivor received a deterministic synthetic killer-experiment fixture with exact labels and fixed budgets. All three passed the implementability Gate.

### Layer E: Stress / falsification boundary
Synthetic sensitivity tests were used to find regimes where the Ideas lose value:
- C15: proxy quality is a critical variable.
- C16: tiny verifier shifts create tiny certificate-drift effects.
- C17: stable low-volatility environments show nearly no advantage.

These boundaries were written into Claim Contracts rather than hidden.

## 3. Readiness assessment

### C15
Readiness: HIGHEST  
Reason: direct recent literature establishes a large allocation effect and explicitly leaves scheduler design open. The empirical target is concrete and benchmarkable.  
Main risk: reviewer may view scheduling as an obvious follow-up unless the method handles unknown critical paths and real provenance dependencies.

Next required evidence: real-memory dynamic benchmark + non-oracle scheduler proxies.

### C16
Readiness: HIGH  
Reason: recent systems have started persisting verifier signals, creating a new lifecycle object whose version validity has not been directly characterized in the retrieved literature.  
Main risk: effect size may be too small under realistic verifier updates, or the contribution may collapse into engineering version tags.

Next required evidence: collect realistic V1/V2 verifier transitions and quantify disagreement plus downstream impact.

### C17
Readiness: CONDITIONAL  
Reason: clear systems problem and no directly retrieved lifecycle-maintenance-aware admission objective.  
Main risk: contribution may reduce to ordinary cost-aware utility, and real recurring maintenance costs may be too small.

Next required evidence: maintenance-cost census on real persistent-memory workloads before method implementation.

## 4. Recommended research order

First vertical slice: C15.  
Parallel low-cost diagnostic: C16 verifier-drift census.  
C17 remains frozen until a real cost census establishes that recurring maintenance burden is material.

This ordering is an execution recommendation, not a claim that the other Ideas are scientifically invalid.

## 5. Evidence status

Novelty: current public-search audit passed with stated risks.  
Feasibility: synthetic operationalization passed.  
Scientific hypotheses: UNVERIFIED.  
Real LLM experiments: NOT STARTED.  
Paper claims: NONE FROZEN.

The next state is `PILOT_DESIGN`, with C15 as active candidate.
