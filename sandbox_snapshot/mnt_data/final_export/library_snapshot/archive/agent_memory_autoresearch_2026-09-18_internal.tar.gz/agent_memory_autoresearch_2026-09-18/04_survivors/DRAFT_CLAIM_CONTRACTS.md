# Draft Claim Contracts for Surviving Ideas

这些 Contract 仅冻结“下一阶段要尝试证明什么”，并不代表结论已经成立。

## C15
H1: 固定 verification budget 下，risk-aware recertification scheduling 降低 stale-induced action error。  
H2: 收益随 bank size、churn、dependency depth 增加。  
Primary falsifier: simple TTL/oldest-first 与 proposed 无差异。  
Primary control: 相同 verification calls、相同可见 metadata、相同 backbone。

## C16
H1: verifier migration 产生 certificate drift。  
H2: selective recertification 接近 full revalidation，同时降低成本。  
Primary falsifier: realistic verifier upgrades 下 disagreement 太小，或 random recertification 同样有效。  
Primary control: memory content 完全冻结，只改变 verifier version。

## C17
H1: utility-only admission 在动态长期 workload 下积累 recurring maintenance burden。  
H2: NLV admission 提高 cumulative utility per total lifecycle cost。  
Primary falsifier: 简单 one-shot cost penalty 即可完全复现效果，或 recurring maintenance cost 实际占比过低。  
Primary control: 相同 capacity、相同 total lifecycle budget、相同 downstream agent。
