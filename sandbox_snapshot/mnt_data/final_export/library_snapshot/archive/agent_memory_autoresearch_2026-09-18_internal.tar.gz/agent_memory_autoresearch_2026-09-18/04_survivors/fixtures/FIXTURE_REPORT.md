# Synthetic Feasibility Fixture Report

研究批次：AM-AUTO-20260918-R1  
性质：**实验可实施性验证，不属于论文实证结果。**

本轮 fixture 只验证问题能否被精确定义、是否存在确定性标签、所选指标能否在受控条件下区分机制。所有数据均为合成数据，因此任何数值都不得写入未来论文作为真实 Agent 效果。

## C15 Budgeted Memory Recertification Scheduler

40 个随机种子，固定验证预算为 memory bank 的 5%。

- Random 平均避免 stale loss：5.22%
- Oldest-first：8.22%
- Relevance-first：11.66%
- Risk scheduler：27.50%
- Oracle：28.06%

Risk scheduler 在该受控生成机制下接近 oracle，说明 `staleness × future use × downstream loss` 可以形成可判分的调度任务。

### 压力测试
估计噪声从 0.03 增加到 0.35，预算从 1% 到 10%。所有测试组合中，risk scheduler 相对最佳 simple baseline 的 stale-loss-prevention 绝对优势保持为正，最小约 3.81%，最大约 20.76%。

### 当前结论
可实施性 Gate：PASS。  
科学假设状态：UNVERIFIED。  
最关键真实测试：在无 oracle critical path、仅可使用真实系统可观测元数据时，优势是否仍存在。

## C16 Version-Bound Verifier Certificates

40 个随机种子，synthetic V1 → V2 migration：

- 旧 certificate 与 V2 的平均不一致率：4.63%
- 15% 随机重认证后：3.94%
- 15% margin-based：1.60%
- 15% drift-aware：0.41%

fixture 表明“内容保持不变而 certificate 因 verifier 版本变化失效”可以单独构造，并且 selective recertification 具有明确预算轴。

### 压力测试
当 verifier shift 很小时，stale-certificate error 仅约 0.4%，问题影响自然缩小；shift 增大后错误上升至约 4.8%。这给出了非常重要的 kill boundary：真实系统中的 verifier upgrade 若几乎不改变决策区域，C16 的论文价值会显著下降。

### 当前结论
可实施性 Gate：PASS。  
科学假设状态：UNVERIFIED。  
最关键真实测试：收集真实 verifier model/prompt/rubric 版本迁移，测实际 disagreement 和 downstream impact。

## C17 Maintenance-Aware Memory Admission

40 个随机种子。

动态 regime：
- Utility-only net lifetime value：11955.5
- Maintenance-aware：14000.0
- Utility-only maintenance cost：8421.6
- Maintenance-aware maintenance cost：4988.9

稳定 regime：
- Utility-only net lifetime value：19488.9
- Maintenance-aware：19529.3

### 压力测试
volatility scale 从 0.05 增长到 1.5，maintenance-aware 相对 net-value 增益从约 0.01% 增至 41.79%。这说明该 Idea 的价值集中在动态环境，稳定环境中会自然退化到普通 utility admission。

### 当前结论
可实施性 Gate：PASS。  
科学假设状态：UNVERIFIED。  
最大风险：reviewer 可能将方法解释成普通 cost-aware utility。后续研究必须证明 recurring maintenance externality 在真实 Agent workload 中足够大，并且 one-shot latency/storage penalty 无法解释全部结果。

## 总体判断

三个 Idea 都通过“问题可操作化 + Killer Experiment 可精确判分”的工程 Gate。fixture 同时确定了三条明确边界：

1. C15 依赖可估计的 staleness/use/consequence 信号，真实系统中这些 proxy 的质量决定价值。
2. C16 依赖 verifier migration 产生足够大的 decision-region drift。
3. C17 主要服务高动态、高维护负担环境，稳定环境不期待显著收益。

这些边界会直接进入后续 Claim Contract，避免正式实验失败后临时修改故事。
