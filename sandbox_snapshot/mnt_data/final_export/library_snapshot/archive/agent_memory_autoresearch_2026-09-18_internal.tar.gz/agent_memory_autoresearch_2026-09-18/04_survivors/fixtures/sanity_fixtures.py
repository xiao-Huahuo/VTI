"""
Deterministic synthetic feasibility fixtures for AM-AUTO-20260918-R1.

These fixtures are NOT empirical evidence for a paper. They only check:
1. the proposed variables can be operationalized,
2. the killer experiments have exact labels,
3. the metrics can distinguish the hypothesized mechanisms in a controlled world.
"""
from __future__ import annotations
import numpy as np
import json
from pathlib import Path

OUT = Path(__file__).with_name("fixture_results.json")

def ci95(xs):
    a = np.asarray(xs, dtype=float)
    return {
        "mean": float(a.mean()),
        "std": float(a.std(ddof=1)),
        "ci95_halfwidth": float(1.96 * a.std(ddof=1) / np.sqrt(len(a))),
    }

def c15(seed: int):
    rng = np.random.default_rng(seed)
    n, budget = 1200, 60

    age = rng.uniform(0, 1, n)
    source_churn = rng.beta(2.0, 5.0, n)
    future_use = rng.beta(1.7, 4.0, n)
    consequence = np.exp(rng.normal(0.0, 0.75, n))

    # Ground-truth stale probability. Age is informative but not sufficient.
    logit = -3.0 + 2.2 * age + 4.3 * source_churn
    p_stale = 1 / (1 + np.exp(-logit))
    stale = rng.random(n) < p_stale

    # Scheduler has noisy estimates rather than oracle p_stale/future_use.
    churn_hat = np.clip(source_churn + rng.normal(0, 0.07, n), 0, 1)
    use_hat = np.clip(future_use + rng.normal(0, 0.05, n), 0, 1)
    logit_hat = -3.0 + 2.2 * age + 4.3 * churn_hat
    stale_hat = 1 / (1 + np.exp(-logit_hat))

    risk_score = stale_hat * use_hat * consequence
    relevance_score = use_hat
    oldest_score = age

    policies = {
        "random": rng.choice(n, budget, replace=False),
        "oldest": np.argsort(oldest_score)[-budget:],
        "relevance": np.argsort(relevance_score)[-budget:],
        "risk_scheduler": np.argsort(risk_score)[-budget:],
        "oracle": np.argsort(p_stale * future_use * consequence)[-budget:],
    }

    actual_loss = stale * future_use * consequence
    total = actual_loss.sum()
    result = {}
    for name, idx in policies.items():
        prevented = actual_loss[idx].sum()
        result[name] = {
            "prevented_stale_loss": float(prevented),
            "residual_stale_loss": float(total - prevented),
            "fraction_prevented": float(prevented / total if total else 0.0),
        }
    return result

def c16(seed: int):
    rng = np.random.default_rng(seed)
    n, budget = 2000, 300

    x = rng.normal(0, 1, n)
    category = rng.integers(0, 4, n)
    # V1 and V2 are deterministic verifiers over the same unchanged memories.
    v1_score = x + np.where(category == 1, 0.15, 0.0)
    v2_score = x + np.where(category == 1, -0.20, 0.0) + np.where(category == 3, 0.12, 0.0)
    v1 = v1_score >= 0.0
    v2 = v2_score >= 0.0

    stale_cert_error = np.mean(v1 != v2)
    disagreement = v1 != v2

    # Observable migration-risk proxies:
    # category 1 changed policy most, category 3 changed mildly, low V1 margin is risky.
    margin = np.abs(v1_score)
    drift_risk = (category == 1) * 2.0 + (category == 3) * 0.7 + 1.0 / (margin + 0.08)

    random_idx = rng.choice(n, budget, replace=False)
    margin_idx = np.argsort(-margin)[:budget]  # smallest margin because argsort(-?) corrected below
    margin_idx = np.argsort(margin)[:budget]
    drift_idx = np.argsort(drift_risk)[-budget:]

    def error_after(idx):
        cert = v1.copy()
        cert[idx] = v2[idx]
        return float(np.mean(cert != v2))

    return {
        "stale_certificate_error": float(stale_cert_error),
        "full_recertification_error": 0.0,
        "random_partial_error": error_after(random_idx),
        "margin_partial_error": error_after(margin_idx),
        "drift_aware_partial_error": error_after(drift_idx),
        "budget_fraction": budget / n,
        "disagreement_count": int(disagreement.sum()),
    }

def c17(seed: int, regime: str):
    rng = np.random.default_rng(seed)
    n, capacity, horizon = 1600, 260, 80

    use_prob = rng.beta(1.8, 5.0, n)
    utility_per_use = np.exp(rng.normal(0.2, 0.55, n))
    initial_value = horizon * use_prob * utility_per_use

    if regime == "dynamic":
        change_hazard = rng.beta(2.0, 4.0, n)
        verify_cost = np.exp(rng.normal(-0.2, 0.6, n))
        conflict_cost = np.exp(rng.normal(-1.0, 0.7, n))
    elif regime == "stable":
        change_hazard = rng.beta(0.7, 12.0, n)
        verify_cost = np.exp(rng.normal(-0.8, 0.35, n))
        conflict_cost = np.exp(rng.normal(-1.8, 0.4, n))
    else:
        raise ValueError(regime)

    # Expected recurring cost over lifetime.
    expected_maintenance = horizon * (
        change_hazard * verify_cost
        + use_prob * change_hazard * conflict_cost
        + 0.012  # indexing/retrieval participation cost
    )
    nlv = initial_value - expected_maintenance

    idx_utility = np.argsort(initial_value)[-capacity:]
    idx_nlv = np.argsort(nlv)[-capacity:]

    # Realized workload.
    uses = rng.binomial(horizon, use_prob)
    changes = rng.binomial(horizon, change_hazard)
    realized_gross = uses * utility_per_use
    realized_cost = changes * verify_cost + uses * change_hazard * conflict_cost + horizon * 0.012
    realized_net = realized_gross - realized_cost

    def summarize(idx):
        gross = float(realized_gross[idx].sum())
        cost = float(realized_cost[idx].sum())
        net = float(realized_net[idx].sum())
        return {
            "gross_utility": gross,
            "maintenance_cost": cost,
            "net_lifetime_value": net,
            "utility_per_total_cost_proxy": float(gross / (cost + 1e-9)),
        }

    return {
        "utility_only": summarize(idx_utility),
        "maintenance_aware": summarize(idx_nlv),
        "overlap_fraction": float(len(set(idx_utility).intersection(set(idx_nlv))) / capacity),
    }

def main():
    seeds = list(range(40))
    c15_runs = [c15(s) for s in seeds]
    c16_runs = [c16(s) for s in seeds]
    c17_dyn = [c17(s, "dynamic") for s in seeds]
    c17_stable = [c17(s, "stable") for s in seeds]

    c15_summary = {}
    for policy in ["random","oldest","relevance","risk_scheduler","oracle"]:
        c15_summary[policy] = ci95([r[policy]["fraction_prevented"] for r in c15_runs])

    c16_summary = {
        k: ci95([r[k] for r in c16_runs])
        for k in [
            "stale_certificate_error","random_partial_error",
            "margin_partial_error","drift_aware_partial_error"
        ]
    }

    def c17_summary(runs):
        return {
            "utility_only_net": ci95([r["utility_only"]["net_lifetime_value"] for r in runs]),
            "maintenance_aware_net": ci95([r["maintenance_aware"]["net_lifetime_value"] for r in runs]),
            "utility_only_maintenance": ci95([r["utility_only"]["maintenance_cost"] for r in runs]),
            "maintenance_aware_maintenance": ci95([r["maintenance_aware"]["maintenance_cost"] for r in runs]),
            "overlap_fraction": ci95([r["overlap_fraction"] for r in runs]),
        }

    out = {
        "disclaimer": "Synthetic feasibility fixtures only. Not paper evidence.",
        "seeds": seeds,
        "C15": c15_summary,
        "C16": c16_summary,
        "C17_dynamic": c17_summary(c17_dyn),
        "C17_stable": c17_summary(c17_stable),
        "gates": {
            "C15_fixture_pass": c15_summary["risk_scheduler"]["mean"] > c15_summary["oldest"]["mean"]
                                and c15_summary["risk_scheduler"]["mean"] > c15_summary["relevance"]["mean"],
            "C16_fixture_pass": c16_summary["stale_certificate_error"]["mean"] > 0.02
                                and c16_summary["drift_aware_partial_error"]["mean"] < c16_summary["random_partial_error"]["mean"],
            "C17_fixture_pass": c17_summary(c17_dyn)["maintenance_aware_net"]["mean"] > c17_summary(c17_dyn)["utility_only_net"]["mean"],
        }
    }
    OUT.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out["gates"], indent=2))
    print("C15 risk vs oldest/relevance:",
          out["C15"]["risk_scheduler"]["mean"],
          out["C15"]["oldest"]["mean"],
          out["C15"]["relevance"]["mean"])
    print("C16 stale/random/drift:",
          out["C16"]["stale_certificate_error"]["mean"],
          out["C16"]["random_partial_error"]["mean"],
          out["C16"]["drift_aware_partial_error"]["mean"])
    print("C17 dynamic net utility-only vs maintenance-aware:",
          out["C17_dynamic"]["utility_only_net"]["mean"],
          out["C17_dynamic"]["maintenance_aware_net"]["mean"])
    print("C17 stable net utility-only vs maintenance-aware:",
          out["C17_stable"]["utility_only_net"]["mean"],
          out["C17_stable"]["maintenance_aware_net"]["mean"])

if __name__ == "__main__":
    main()
