"""
Stress tests for the three surviving ideas.
Synthetic only. The goal is to locate failure boundaries, not to claim empirical effectiveness.
"""
import numpy as np, json
from pathlib import Path

OUT = Path(__file__).with_name("stress_results.json")

def c15_once(seed, noise, budget_frac):
    rng = np.random.default_rng(seed)
    n = 1500
    budget = max(1, int(n * budget_frac))
    age = rng.uniform(0,1,n)
    churn = rng.beta(2,5,n)
    use = rng.beta(1.7,4,n)
    loss = np.exp(rng.normal(0,0.75,n))
    p = 1/(1+np.exp(-(-3+2.2*age+4.3*churn)))
    stale = rng.random(n)<p
    churn_hat = np.clip(churn+rng.normal(0,noise,n),0,1)
    use_hat = np.clip(use+rng.normal(0,noise*0.75,n),0,1)
    p_hat = 1/(1+np.exp(-(-3+2.2*age+4.3*churn_hat)))
    scores = {
        "oldest": age,
        "relevance": use_hat,
        "risk": p_hat*use_hat*loss
    }
    actual = stale*use*loss
    total=actual.sum()
    out={}
    for k,s in scores.items():
        idx=np.argsort(s)[-budget:]
        out[k]=actual[idx].sum()/total
    return out

def c16_once(seed, shift, budget_frac):
    rng=np.random.default_rng(seed)
    n=2500
    budget=int(n*budget_frac)
    x=rng.normal(0,1,n)
    cat=rng.integers(0,4,n)
    v1score=x+np.where(cat==1,0.1,0)
    v2score=x+np.where(cat==1,0.1-shift,0)+np.where(cat==3,shift*0.35,0)
    v1=v1score>=0
    v2=v2score>=0
    margin=np.abs(v1score)
    risk=(cat==1)*2+(cat==3)*0.6+1/(margin+0.08)
    idx=np.argsort(risk)[-budget:]
    cert=v1.copy(); cert[idx]=v2[idx]
    stale=np.mean(v1!=v2)
    selective=np.mean(cert!=v2)
    rnd=rng.choice(n,budget,replace=False)
    cert2=v1.copy(); cert2[rnd]=v2[rnd]
    random_err=np.mean(cert2!=v2)
    return stale,selective,random_err

def c17_once(seed, volatility_scale):
    rng=np.random.default_rng(seed)
    n,cap,H=1800,280,80
    use=rng.beta(1.8,5,n)
    util=np.exp(rng.normal(0.2,0.55,n))
    initial=H*use*util
    base=rng.beta(2,4,n)
    hazard=np.clip(base*volatility_scale,0,1)
    vcost=np.exp(rng.normal(-0.25,0.6,n))
    ccost=np.exp(rng.normal(-1,0.7,n))
    exp_cost=H*(hazard*vcost+use*hazard*ccost+0.012)
    nlv=initial-exp_cost
    iu=np.argsort(initial)[-cap:]
    im=np.argsort(nlv)[-cap:]
    uses=rng.binomial(H,use)
    changes=rng.binomial(H,hazard)
    gross=uses*util
    cost=changes*vcost+uses*hazard*ccost+H*0.012
    net=gross-cost
    return net[iu].sum(), net[im].sum()

def avg(xs):
    return float(np.mean(xs))

def main():
    seeds=range(30)
    out={"C15":[],"C16":[],"C17":[]}

    for noise in [0.03,0.10,0.20,0.35]:
        for b in [0.01,0.05,0.10]:
            runs=[c15_once(s,noise,b) for s in seeds]
            risk=avg([r["risk"] for r in runs])
            oldest=avg([r["oldest"] for r in runs])
            rel=avg([r["relevance"] for r in runs])
            out["C15"].append({
                "estimate_noise":noise,"budget_fraction":b,
                "risk_fraction_prevented":risk,
                "oldest_fraction_prevented":oldest,
                "relevance_fraction_prevented":rel,
                "risk_minus_best_simple":risk-max(oldest,rel)
            })

    for shift in [0.03,0.08,0.18,0.35]:
        for b in [0.05,0.15,0.30]:
            runs=[c16_once(s,shift,b) for s in seeds]
            out["C16"].append({
                "verifier_shift":shift,"budget_fraction":b,
                "stale_cert_error":avg([x[0] for x in runs]),
                "selective_error":avg([x[1] for x in runs]),
                "random_error":avg([x[2] for x in runs]),
            })

    for scale in [0.05,0.15,0.35,0.70,1.0,1.5]:
        runs=[c17_once(s,scale) for s in seeds]
        u=avg([x[0] for x in runs]); m=avg([x[1] for x in runs])
        out["C17"].append({
            "volatility_scale":scale,
            "utility_only_net":u,
            "maintenance_aware_net":m,
            "relative_gain":(m-u)/(abs(u)+1e-9)
        })

    OUT.write_text(json.dumps(out,indent=2),encoding="utf-8")
    print("C15 worst margin:", min(x["risk_minus_best_simple"] for x in out["C15"]))
    print("C15 best margin:", max(x["risk_minus_best_simple"] for x in out["C15"]))
    print("C16 cases:")
    for x in out["C16"]:
        print(x)
    print("C17:")
    for x in out["C17"]:
        print(x)

if __name__=="__main__":
    main()
