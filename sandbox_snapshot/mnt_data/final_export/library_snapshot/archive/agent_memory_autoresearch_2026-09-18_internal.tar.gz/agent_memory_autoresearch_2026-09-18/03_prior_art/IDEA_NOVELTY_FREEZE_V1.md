# IDEA Novelty Freeze v1

Project: AM-AUTO-20260918-R1  
Cutoff: 2026-09-18  
Scope: Agent Memory, persistent long-term memory lifecycle  
Status: PRELIMINARY_IDEA_FREEZE

## C15 Budgeted Memory Recertification Scheduler
Decision: PASS  
Direct precursor: arXiv:2608.25553.  
Key distinction frozen for next stage: precursor demonstrates that verification allocation matters using known critical provenance and explicitly states that its intervention is not a scheduler. C15 studies online/non-oracle allocation of limited recertification budget over a long-lived memory bank.

Forbidden novelty overclaim:
- “first work on stale memory verification”
- “first work on budgeted memory verification”
- “first work showing allocation matters”

Permitted hypothesis to test:
- risk-aware scheduling can learn/estimate which memories to re-check under a fixed budget without gold critical-path knowledge.

## C16 Version-Bound Verifier Certificates
Decision: PASS WITH MEDIUM NOVELTY RISK  
Direct precursor: MemGuard arXiv:2608.21867 persists verifier-derived reward/confidence/label/uncertainty through the memory lifecycle.  
Key distinction frozen for next stage: C16 studies validity of that metadata after the verifier itself changes.

Forbidden novelty overclaim:
- “first persistent verifier metadata”
- “first versioned memory”
- “first memory governance framework”

Permitted hypothesis to test:
- verifier updates create systematic certificate drift and selective recertification can recover current-verifier consistency under lower cost than full revalidation.

## C17 Maintenance-Aware Memory Admission
Decision: PASS WITH HIGHER NOVELTY RISK  
Direct precursor: A-MAC arXiv:2603.04549 performs interpretable admission from future utility, confidence, novelty, recency and type prior. Agentic Technical Debt arXiv:2608.01001 already establishes broad debt terminology.

Key distinction frozen for next stage: C17 optimizes admission using recurring lifecycle costs incurred after acceptance, especially revalidation/conflict/migration/re-indexing costs over long horizons.

Forbidden novelty overclaim:
- “first memory admission control”
- “first memory cost-aware agent”
- “first Agentic/Memory Technical Debt”

Permitted hypothesis to test:
- recurring maintenance externalities change the optimal admission decision under dynamic long-lived workloads.

## Freeze rule
Any new paper that directly covers the frozen distinction triggers a new Novelty Audit before code expansion.
