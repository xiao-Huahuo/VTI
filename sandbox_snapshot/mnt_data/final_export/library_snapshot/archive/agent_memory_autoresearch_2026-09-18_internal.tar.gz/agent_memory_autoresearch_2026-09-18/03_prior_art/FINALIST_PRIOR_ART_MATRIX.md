# Finalist Prior-Art Matrix

## C15 Budgeted Memory Recertification Scheduler

| Work | Problem | Mechanism | 与 C15 的关系 |
|---|---|---|---|
| When Stale Constraints Go Unchecked | 固定验证预算下 stale inherited constraint 未被检查 | native allocation 与人工 critical-path reallocation | 最直接 precursor。论文明确说明 intervention 依赖已知 critical path，且不是 scheduler |
| Tiered/selective verification works | query-time 选择性核验 | 对当前查询涉及证据做验证 | 邻近，但关注 query-local verification，未形成长期记忆维护调度 |
| Churn/cache freshness work | 动态环境缓存刷新 | TTL / refresh policy | 系统层邻近，不等价于 agent persistent memory 的 provenance-aware recertification |

剩余缺口：在长期记忆库上，在未知 critical path、有限维护预算、未来使用分布未知或可估计时，自动分配 recertification budget。

Novelty risk: LOW-MEDIUM  
Status: SURVIVOR

## C16 Version-Bound Verifier Certificates

| Work | Problem | Mechanism | 与 C16 的关系 |
|---|---|---|---|
| MemGuard | verifier 结果不能只做一次过滤 | reward/confidence/label/uncertainty 作为持久 metadata | 直接创造了“证书会长期存在”的前提，但摘要与本轮检索未覆盖 verifier version drift |
| Model-upgrade memory portability | backbone 升级后记忆迁移 | schema/raw history/embedding migration | 研究被消费模型变化，不是验证器变化 |
| Persistent-memory governance specs | version/provenance/policy metadata | architecture-level versioning | 工程规范邻近，缺少 verifier-drift 的实证问题与 selective recertification 方法 |

剩余缺口：验证器升级后，旧 confidence/label 是否仍具语义有效性，以及怎样低成本选择性重认证。

Novelty risk: MEDIUM  
Status: SURVIVOR

## C17 Maintenance-Aware Memory Admission

| Work | Problem | Mechanism | 与 C17 的关系 |
|---|---|---|---|
| A-MAC | 什么内容值得写入长期记忆 | future utility/confidence/novelty/recency/type prior | 最直接 admission prior art，但 objective 未显式计入持续维护外部性 |
| Shared Selective Persistent Memory | 全历史昂贵且 stale | 选择性保留四类可复用上下文 | 证明 selective retention 的工程价值 |
| Agentic Technical Debt | agent 系统技术债及 memory inconsistency | taxonomy / research agenda | 限制“Memory Debt”首创 claim，但没有形成 admission optimization |
| Lifecycle security survey | memory lifecycle 需要版本、治理、回滚 | lifecycle primitives | 证明维护动作本身是长期系统组成 |

剩余缺口：把 accepted memory 在未来产生的验证、冲突、迁移、索引和检索成本加入准入价值函数，研究长期累积收益而非单次 retrieval/admission 指标。

Novelty risk: MEDIUM  
Status: SURVIVOR
