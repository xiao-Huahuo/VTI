# Agent Memory 领域地图与拥挤度审计

研究批次：AM-AUTO-20260918-R1  
检索截止：2026-09-18  
说明：本文件记录第一轮到第四轮自动科研筛选得到的领域地图。它是研究资产，不等同于正式论文 Related Work。

## 1. 高拥挤区域

### Prospective Memory
近期已有 PM-Bench、TriggerBench、Typed Intention Store 等直接工作。单纯“让 Agent 记住未来任务或触发条件”缺少足够独立性。

### 因果记忆与记忆价值估计
ActMem、MemAudit 及多项基于因果干预、反事实贡献或决策效用的工作已经覆盖“哪些记忆真正导致行动改变”这一问题。仅把相似度检索改成因果打分，创新风险高。

### 检索之后是否真正使用
Mem2ActBench、retrieval-versus-utilization 诊断和个性化 Agent 研究已经把 retrieval/use gap 单独提出。此方向仍有研究空间，但宽泛问题已经形成直接 prior art。

### Reasoning Fixation 与经验跟随
ACL 2026 experience-following 以及 MemTrapBench 已经说明记忆会固定推理路径并传播错误。直接做“防止 Agent 被旧经验带偏”重合明显。

### 记忆整合、可信写入与冲突治理
Memory-R1、AgeMem、RecMem、TRUSTMEM、MemGuard 等已经覆盖 consolidation、write verification、persistent verifier metadata、conflict resolution 等机制。

### Staleness、supersession 与 rollback
STALE、TEPA、ChronoMem、dependency-guided rollback 等对陈旧记忆、时间更新、依赖传播和回滚已有密集研究。只做“检测旧记忆并删除”缺少独立性。

### Scope、intent 与 shared memory
Contextual Intent、Governed Shared Memory 等已研究作用域约束、workspace intent、scoped retrieval 和共享记忆治理。宽泛的“防止跨任务误用记忆”已拥挤。

### 不确定性与 belief memory
BeliefMem 及 MemGuard 已把概率、confidence、uncertainty 作为持久记忆表示或治理信号。单独保存不确定性不足以形成新论文。

### Tool drift 与 procedural memory repair
ProcMEM、ReMe、SkillRevise、environment-probing curation 等已覆盖程序性记忆、工具变化、环境探测和技能修复。

### Authority / provenance laundering
TMA-NM、provenance laundering、endogenous authorization laundering、Authority Collapse at Memory Consolidation 等已经把“推断被洗成事实或权限”做成独立问题。

### Model-upgrade memory portability
2026-09 已出现专门研究模型升级后记忆是否仍可迁移的工作。直接做 model-upgrade migration 风险高。

## 2. 仍显示明显空隙的区域

### A. 有限维护预算下的主动记忆再认证
已有工作已经证明 verification allocation 本身决定 stale-memory 错误，而且最新直接论文明确说明其 critical-path intervention “is not a scheduler”。目前缺少一个面向长期记忆库、在有限维护预算下自动决定“现在先验证哪条记忆”的风险感知调度问题定义与 benchmark。

### B. Verifier 版本漂移导致的证书陈旧
MemGuard 把 verifier 的 reward/confidence/label/uncertainty 作为持久 lifecycle metadata，但现实系统会升级 verifier 模型、prompt、rubric 或 safety policy。当前检索未发现直接研究“内容不变、验证器变化、旧验证标签继续被信任”的系统性工作。

### C. 记忆准入决策中的长期维护外部性
A-MAC 优化 future utility、confidence、novelty、recency、type prior，当前长期记忆研究也广泛关注检索成本，但准入后产生的持续验证、冲突处理、重嵌入、迁移、合规删除等未来维护成本尚未被明确纳入 admission objective。更稳妥的研究表述是“maintenance-aware admission”，而非声称首次提出广义 technical debt。

## 3. 主要直接文献钉子

- When Stale Constraints Go Unchecked: Budgeted Verification Failures in Inherited Agent Memory. arXiv:2608.25553.
- MemGuard: Persisting Verifier Signals for LLM-Agent Memory Governance. arXiv:2608.21867.
- Adaptive Memory Admission Control for LLM Agents. arXiv:2603.04549.
- From AI Technical Debt to Agentic Technical Debt. arXiv:2608.01001.
- A Survey on Long-Term Memory Security in LLM Agents. arXiv:2604.16548.
- Shared Selective Persistent Memory for Agentic LLM Systems. arXiv:2607.09493.

## 4. 当前判断

本轮不再从“设计一种新的 memory store”出发。幸存候选都围绕长期记忆生命周期中的资源分配和治理不变量，要求具有明确失效现象、可控实验和直接可否证机制。
