# Source Inventory

检索截止：2026-09-18

本文件记录本轮筛选中实际影响候选去留的主要来源。正式论文阶段需要再次刷新。

| 类别 | 工作 | 时间/标识 | 本轮用途 |
|---|---|---|---|
| Budgeted verification | When Stale Constraints Go Unchecked | arXiv:2608.25553 | 证明固定验证预算下 allocation 是关键变量，并明确当前干预不是 scheduler |
| Persistent verifier metadata | MemGuard: Persisting Verifier Signals... | arXiv:2608.21867 | 证明 verifier 信号会作为长期 lifecycle metadata 被复用 |
| Admission | Adaptive Memory Admission Control | arXiv:2603.04549 | 当前最直接的结构化准入 prior art |
| Lifecycle security | Survey on Long-Term Memory Security | arXiv:2604.16548 | 生命周期、版本、治理邻近工作 |
| Agentic technical debt | From AI Technical Debt to Agentic Technical Debt | arXiv:2608.01001 | 限制“memory debt”命名与 novelty claim，避免过度声称 |
| Persistent selective memory | Shared Selective Persistent Memory | arXiv:2607.09493 | 长期成本、stale trace 与 selective retention 邻近 |
| Model migration | Does Your Agent’s Memory Survive a Model Upgrade? | arXiv:2609.05339 | 排除单纯 model-upgrade portability Idea |
| Prospective memory | PM-Bench / TriggerBench / Typed Intention Store | 2026 | 淘汰未来触发式记忆候选 |
| Fixation | ACL 2026 experience-following / MemTrapBench | 2026 | 淘汰宽泛 reasoning fixation 候选 |
| Staleness / rollback | STALE / TEPA / ChronoMem | 2026 | 淘汰宽泛 stale-delete / rollback 候选 |
| Scope / intent | Grounding Agent Memory in Contextual Intent | ACL 2026 | 淘汰跨作用域误用候选 |
| Belief uncertainty | BeliefMem | 2026 | 淘汰宽泛 uncertainty-preserving memory 候选 |
| Authority / provenance | TMA-NM / EAL / Authority Collapse | 2026 | 淘汰 authority laundering 候选 |

## 检索说明

针对三个最终幸存候选，又追加了以下反向杀伤检索：

- `"agent memory" "verification budget" scheduler memory recertification`
- `"agent memory" "verifier drift" memory verifier version persistent`
- `"agent memory" lifecycle cost admission maintenance memory debt`
- `"maintenance-aware" "agent memory" admission`
- `"maintenance cost" "memory admission" LLM agent`
- `"recurring verification" "agent memory"`
- `"certificate" "agent memory" verifier metadata version`
- `"verifier version" "long-term memory" LLM agent`
- `"selective recertification" LLM agent memory`

截至检索截止日，后六组精确查询未检出直接同题论文。此结果只表示“本轮公开检索未发现直接重合”，不构成永久新颖性证明。
