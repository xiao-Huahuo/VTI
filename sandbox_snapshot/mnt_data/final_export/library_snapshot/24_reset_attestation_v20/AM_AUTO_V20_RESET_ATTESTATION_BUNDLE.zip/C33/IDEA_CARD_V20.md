# C33 Idea Card V20

Project: AM-AUTO-20260918-R1
Date: 2026-09-19
Title: Residual-State Contamination in Agent Memory Benchmarks
Status: PRIMARY_PROVISIONAL
Novelty risk: MEDIUM_HIGH

## Research question

When an Agent Memory benchmark calls a provider reset or cleanup API and then treats the next case as independent, does the reset contract actually remove every state component that can influence later retrieval or answers?

The causal object is reset completeness, rather than deletion quality in ordinary product use.

## Mechanism

A benchmark commonly assumes:

`reset success -> clean initial state -> independent next case`

C33 tests the first implication directly. Residual state may survive through pagination limits, asynchronous deletion, derived graph state, project-level configuration, caches, summaries, or provider-specific state outside the benchmark adapter's reset surface.

If surviving state remains retrievable or changes later behavior, benchmark cases cease to be independent even though the harness reports a successful reset.

## Concrete source-bound instance

Redis Agent Memory Benchmark commit `94192c39e2a4a154f441a5411e3d73c4f54974a6` calls `store.reset()` before every LongMemEval example and again after the example. Its Mem0 adapter implements reset by calling `Memory.delete_all(user_id=...)`.

Mem0 issue #6627 documents that v2.0.14 `delete_all()` enumerated only the first vector-store page. For nine common vector stores with a default list size of 100, a user with more than 100 memories retained all rows beyond the first page while the API returned `Memories deleted successfully!`. PR #6636 merged the pagination fix on 2026-07-31.

Therefore a real benchmark reset path existed whose success return did not imply an empty namespace.

## Initial source-integration validation

The V20 deterministic fixture reproduces the exact relevant control-flow shape: 150 Run-A memories, single-page deletion of 100, successful reset return, then Run B. Fifty Run-A memories remain and a frozen canary query in Run B retrieves the residual rows.

This is feasibility evidence. It is not a fresh execution of Mem0 Cloud or Mem0 OSS.

## Novelty boundary

C33 does not claim that state leakage, incomplete deletion, benchmark contamination, or namespace isolation are newly discovered concepts.

The retained research contribution under investigation is narrower:

`reset-attested Agent Memory evaluation`: empirically test whether benchmark reset implementations establish observational independence between consecutive cases, and quantify score changes when reset is verified rather than merely invoked.

## Killer Gate

1. Freeze benchmark/provider versions where the reset implementation is known.
2. Run paired sequential cases with unique canaries under ordinary benchmark reset.
3. After every reset, independently enumerate or probe every observable state surface available to the provider.
4. Compare ordinary reset against verified-clean reset or fresh-namespace isolation.
5. Measure residual-state rate and downstream metric delta.

C33 terminates if current representative benchmarks already verify post-reset emptiness across relevant provider state, if direct prior art already performs the same reset-attestation experiment, or if residual state produces no measurable benchmark outcome change outside obsolete fixed versions.
