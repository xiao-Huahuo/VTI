# C33 Static / Source-Integration Gate V20

## Bound source chain

Redis benchmark runner:

`process(example) -> store.reset() -> ingest(example.sessions) -> query -> store.reset()`

Redis Mem0 adapter:

`reset() -> Memory.delete_all(user_id=self._user_id)`

Mem0 v2.0.14 issue #6627:

`delete_all() -> vector_store.list(filters=filters)` with no explicit `top_k`, followed by deletion of only returned IDs. Nine listed vector stores defaulted this enumeration to 100 rows. The call still returned success.

## Deterministic replay

The fixture preserves the relevant semantics without claiming a new provider run.

Run A stores 150 rows under one benchmark namespace. Rows 100 through 149 carry a unique canary. The affected reset path deletes the first 100 rows and returns success. Run B stores five unrelated rows. A canary query after Run-B initialization retrieves Run-A rows.

Observed:

- memories before reset: 150
- reset return: success
- memories remaining after reset: 50
- stale canary retrievable in Run B: yes

## Interpretation

This establishes a complete causal path from an actual benchmark reset call to a documented provider-version reset defect to cross-run retrievability. It establishes feasibility and a historical affected configuration.

It does not establish prevalence across current providers or the magnitude of score contamination on LongMemEval. Those are the next empirical gates.
