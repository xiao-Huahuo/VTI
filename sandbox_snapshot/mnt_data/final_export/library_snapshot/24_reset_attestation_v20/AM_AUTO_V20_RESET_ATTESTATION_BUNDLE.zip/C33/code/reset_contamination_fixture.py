import json
from dataclasses import dataclass
from pathlib import Path

@dataclass
class Memory:
    id: str
    text: str
    user_id: str

class PagedVectorStore:
    """Minimal exact-shape model of affected Mem0 vector-store list semantics."""
    def __init__(self, top_k_default=100):
        self.rows = []
        self.top_k_default = top_k_default

    def add(self, m: Memory):
        self.rows.append(m)

    def list(self, *, filters, top_k=None):
        k = self.top_k_default if top_k is None else top_k
        rows = [r for r in self.rows if r.user_id == filters.get("user_id")]
        return rows[:k], None

    def delete(self, memory_id):
        self.rows = [r for r in self.rows if r.id != memory_id]

    def search(self, query, user_id, top_k=10):
        q = query.lower()
        hits = [r for r in self.rows if r.user_id == user_id and q in r.text.lower()]
        return hits[:top_k]

class Mem0V2014DeleteAll:
    """Exact control-flow shape reported for mem0 v2.0.14 issue #6627."""
    def __init__(self, store):
        self.vector_store = store

    def delete_all(self, user_id):
        memories = self.vector_store.list(filters={"user_id": user_id})[0]
        for memory in memories:
            self.vector_store.delete(memory.id)
        return {"message": "Memories deleted successfully!"}

class RedisBenchmarkMem0Adapter:
    """Reset contract from redis/agent-memory-server pinned benchmark."""
    def __init__(self, memory, user_id):
        self._memory = memory
        self._user_id = user_id

    def reset(self):
        return self._memory.delete_all(user_id=self._user_id)


def run():
    user = "benchmark-shared-user"
    store = PagedVectorStore(top_k_default=100)
    mem0 = Mem0V2014DeleteAll(store)
    adapter = RedisBenchmarkMem0Adapter(mem0, user)

    # Run A: 150 memories. Last 50 carry a marker that run B will query.
    for i in range(150):
        marker = " RESIDUAL-CANARY" if i >= 100 else ""
        store.add(Memory(id=f"A-{i:03d}", text=f"run-A fact {i}{marker}", user_id=user))

    before = len(store.list(filters={"user_id": user}, top_k=10000)[0])
    reset_return = adapter.reset()
    after_reset_rows = store.list(filters={"user_id": user}, top_k=10000)[0]

    # Run B starts after benchmark reset and adds unrelated data.
    for i in range(5):
        store.add(Memory(id=f"B-{i:03d}", text=f"run-B fresh fact {i}", user_id=user))

    stale_hits = store.search("residual-canary", user_id=user, top_k=10)
    result = {
        "fixture_scope": "source-integration feasibility, not a fresh provider execution",
        "mem0_logic": "v2.0.14 issue #6627 single-page delete_all",
        "benchmark_reset": "Redis Mem0 adapter calls delete_all(user_id=...) before/after examples",
        "run_a_count_before_reset": before,
        "reset_return": reset_return,
        "remaining_after_reset": len(after_reset_rows),
        "remaining_ids_head": [r.id for r in after_reset_rows[:5]],
        "run_b_new_count": 5,
        "stale_marker_hits_in_run_b": len(stale_hits),
        "stale_hit_ids": [r.id for r in stale_hits],
        "cross_run_contamination": bool(stale_hits),
        "expected": {
            "remaining_after_reset": 50,
            "cross_run_contamination": True
        }
    }
    assert result["remaining_after_reset"] == 50
    assert result["cross_run_contamination"] is True
    return result

if __name__ == "__main__":
    out = run()
    path = Path(__file__).resolve().parents[1] / "results" / "reset_fixture.json"
    path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))
