# V20 Decision Summary

C33 `Residual-State Contamination in Agent Memory Benchmarks` becomes the sole primary provisional replacement candidate.

The candidate is source-bound rather than hypothetical. A pinned Redis benchmark resets every LongMemEval example through the Mem0 adapter's `delete_all(user_id=...)`. Mem0 v2.0.14 had a documented first-page-only `delete_all` defect for nine common vector-store backends, returning success while leaving rows beyond the first 100. The deterministic V20 source-integration fixture reproduces the resulting cross-run canary retrieval.

Three nearby ideas were screened out before promotion: benchmark-to-production path fidelity, shadow-memory attribution, and derived-state correction reach all have stronger direct prior art than C33.

C33 still remains in Idea Validation. The next decisive Gate is a reset-attestation census across frozen affected and fixed provider versions, followed by paired benchmark replay comparing ordinary invoke-only reset with independently verified clean reset. Formal Experiment remains locked until residual state is shown to alter real benchmark outcomes beyond one historical defect.
