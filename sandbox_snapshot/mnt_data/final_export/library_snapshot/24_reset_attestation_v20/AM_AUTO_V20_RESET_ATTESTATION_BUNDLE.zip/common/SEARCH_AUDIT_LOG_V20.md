# Search / Audit Log V20

Date: 2026-09-19

Replacement screening intentionally excluded asynchronous readiness variants after C30 closure.

Search axes included benchmark-production path fidelity, hidden/shadow memory attribution, derived-state correction reach, reset isolation, cleanup completeness, cross-run contamination, provider reset semantics and benchmark namespace assumptions.

Key decisions:

- production-path fidelity: broad idea rejected due strong existing practice and explicit public incidents;
- shadow-memory attribution: rejected after direct public research framing was found;
- derived correction reach: rejected due direct benchmark-spec overlap;
- reset attestation: retained provisionally because a real benchmark reset path binds to a documented silent partial-reset defect, while no exact multi-provider reset-attestation + outcome-impact study was found.

Source-bound C33 evidence:

- Redis benchmark commit `94192c39e2a4a154f441a5411e3d73c4f54974a6` resets each example;
- Redis Mem0 adapter calls `Memory.delete_all(user_id=...)`;
- Mem0 issue #6627 documents v2.0.14 first-page-only deletion for nine common stores;
- Mem0 PR #6636 merged a pagination fix on 2026-07-31;
- MemArena also uses `delete_all(user_id=namespace)` as its Mem0 reset contract and describes clean namespace as a benchmark assumption.
