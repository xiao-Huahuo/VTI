# Prior-Art Matrix V20

## C33

Closest material found:

1. Agent-memory benchmark and evaluation guides routinely demand clean namespaces or isolated workspaces, establishing contamination as a known concern.
2. Engram explicitly recommends distinct agents or a verified full reset between conditions.
3. MemArena states reset-before-first-ingest as the assumption that prevents leftovers and separately notes asynchronous reset risk.
4. Mem0 issue #6627 demonstrates a real scoped reset that returned success while leaving rows behind; PR #6636 fixed it.
5. Zep documentation distinguishes deletion scopes, including historical session deletion semantics where session deletion did not imply graph deletion, showing why reset surface must match provider state surface.

No source found in the V20 search that turns these concerns into the exact paired experiment: benchmark reset invocation versus independently attested post-reset state, followed by downstream benchmark metric comparison across multiple Agent Memory providers.

Novelty status: provisional, MEDIUM_HIGH risk. The contribution must remain reset attestation and outcome impact, not generic contamination or deletion correctness.

## C34

Directly crowded by production-path benchmark guidance and public incidents where benchmark-only paths diverged from shipped runtime paths. Killed.

## C35

Direct public research framing found for evaluation contamination and shadow-memory attribution. Killed.

## C36

Direct public correction-test specifications include derived artifact reach. Killed.
