# V22 Decision Summary

C33 survives and is stronger than V21.

The project now has real provider-level evidence for multiple independent cleanup failure mechanisms. Mem0's local-Qdrant reset bug was maintainer-confirmed, deterministically regression-tested and fixed in merged PR #6412. The Valkey reset defect remains visible in current Mem0 main: index deletion does not remove backing hashes, while reset recreates the index over the same prefix. Historical single-page `delete_all()` provides a third independent mechanism.

These findings support the existence of a reset-contract defect class. They do not yet prove that reset attestation changes published Agent Memory benchmark scores. The reported Valkey benchmark collapse is kept outside frozen evidence because its provenance is internally inconsistent and no raw artifact has been found.

C33 therefore remains in Idea Validation. The next decisive experiment is invoke-only reset versus independently verified-clean reset on a real affected backend, followed by paired retrieval and answer scoring.
