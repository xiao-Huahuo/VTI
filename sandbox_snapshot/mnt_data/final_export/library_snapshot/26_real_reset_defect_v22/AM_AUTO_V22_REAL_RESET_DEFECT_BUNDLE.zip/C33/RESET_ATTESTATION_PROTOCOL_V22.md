# Reset Attestation Protocol V22

## Objective

Convert benchmark cleanup from a method invocation into a falsifiable state postcondition.

## Contract

For every benchmark case or run boundary, the harness records three states:

1. pre-reset fingerprint;
2. reset return result;
3. post-reset attestation.

A clean transition requires the post-reset attestation to show zero reachable state from the previous run under every read surface that can influence the next evaluation.

## Minimum attestation

For a scoped memory backend:

- enumerate or count scoped canonical memories;
- issue a frozen canary query that uniquely matches Run A;
- inspect backend-visible storage when an independent storage API exists;
- record derived-state surfaces separately when the provider exposes graph, summary or history layers.

The benchmark proceeds only after all required assertions pass, or records the case as `RESET_UNATTESTED`.

## Paired experiment

Treatment A uses the benchmark's existing reset behavior.

Treatment B invokes the same reset, then verifies absence. If residue exists, B applies backend-appropriate cleanup until the same attestation passes.

No other configuration changes between arms.

Primary outcomes:
- residual-state incidence;
- residual canary retrieval rate;
- delta Recall@k / MRR where retrieval metrics exist;
- answer-change rate;
- contamination direction, including false positive recall and stale-answer errors.

## Scope discipline

A reset defect can be platform, backend, version or configuration specific. Every result must stamp all four. Cross-provider prevalence is reported as a census, not inferred from one defect.

## Kill rule

C33 loses main-paper status if real affected configurations exhibit residue but paired benchmark scores remain materially unchanged, or if direct prior art is found that already performs reset attestation and outcome replay across Agent Memory systems.
