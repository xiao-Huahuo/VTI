# C33 Real Provider Reset-Defect Gate V22

Project: AM-AUTO-20260918-R1
Date: 2026-09-19
Decision: PROMOTE_REAL_PROVIDER_DEFECT_CLASS, KEEP_OUTCOME_GATE_LOCKED

## Evidence 1: Mem0 delete_all pagination

Mem0 issue #6627 documents version 2.0.14 where `Memory.delete_all()` enumerated one vector-store page. Nine listed providers defaulted that page to 100 items. The operation could leave all later items behind while returning a success message. PR #6636 merged a pagination fix.

This binds C33 to a real tenant-scoped cleanup defect.

## Evidence 2: local Qdrant reset resurrection

Mem0 issue #6411 and merged PR #6412 establish a different reset failure. On filesystems where an open SQLite handle blocks directory unlink, local Qdrant's drop/recreate reset path can re-adopt the surviving storage file and resurrect every point.

The important evidence upgrade comes from maintainer review. A Mem0 maintainer wrote that the bug was real, corrected the scope to Windows, NFS and Docker bind mounts from Windows hosts, made the regression deterministic by suppressing `shutil.rmtree`, mutation-tested it, and approved the merged fix.

This is independent of #6627. The failure is storage-lifecycle resurrection rather than pagination truncation.

## Evidence 3: Valkey reset resurrection on current main

Mem0 issue #6995 identifies a third mechanism: Valkey `delete_col()` drops the search index while preserving `mem0:<collection>:*` hashes. `reset()` immediately recreates an index over the same prefix, which can re-index the preserved hashes.

PR #6996 proposes explicit `SCAN` plus `UNLINK` of backing hashes and adds a regression test whose rationale is exactly that surviving hashes would be re-indexed after reset. A second contributor independently reviewed the fix direction. Current Mem0 main was re-read on 2026-09-19 and still contains the old bare `FT.DROPINDEX` implementation and the old test expectation, so this defect remains present in current source at audit time.

The original issue also reports a benchmark with about 3,400 stale documents and Recall@1 = 0.000. That number is not promoted because the issue ends with a conflicting statement saying the author did not personally reproduce the AI-generated report, and no raw benchmark artifact has been located.

## Evidence 4: reset semantics can fail in the opposite direction

Mem0 issue #6279 documents Pinecone reset/delete semantics that ignored a configured namespace and operated on the whole shared index. This is primarily destructive over-reset, not residual-state contamination, so it is adjacent evidence rather than support for C33's residual-state main claim.

Together these cases show that `reset()` is not a uniform semantic primitive across memory backends. A benchmark that treats method return as proof of an independent initial state inherits provider-specific cleanup semantics.

## Revised C33 boundary

The retained research contribution is not "reset bugs exist." That is established engineering reality.

C33 asks whether Agent Memory benchmarks need an explicit reset-attestation contract, and whether independently verifying post-reset absence changes reported benchmark outcomes.

The experimental unit is therefore:

`run A -> invoke reset -> attest absence -> run B -> compare against verified-clean control`

Attestation must observe externally relevant state rather than only the reset return code.

## Next hard Gate

1. Freeze at least one affected real provider/backend combination.
2. Run a canary reset attestation with direct storage or provider-visible verification.
3. Execute paired benchmark replay:
   - arm A: ordinary benchmark reset;
   - arm B: reset plus independent absence attestation and remediation until clean.
4. Compare retrieval set, recall metrics and downstream answers.
5. Kill the main idea if verified-clean and invoke-only arms are materially equivalent in affected configurations.
