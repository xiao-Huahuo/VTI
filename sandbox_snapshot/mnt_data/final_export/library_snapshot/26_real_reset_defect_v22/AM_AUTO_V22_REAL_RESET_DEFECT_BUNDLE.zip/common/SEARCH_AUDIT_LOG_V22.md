# Search and Evidence Audit V22

Search cutoff: 2026-09-19

Audited evidence:
- Mem0 #6627 and merged #6636: silent partial `delete_all()` across vector-store pages.
- Mem0 #6411 and merged #6412: local Qdrant reset resurrection on Windows/NFS/Windows-host bind mounts; maintainer-confirmed and mutation-tested.
- Mem0 #6995 and PR #6996: Valkey index reset leaves backing hashes; current main still carries bare `FT.DROPINDEX`.
- Mem0 #6279: Pinecone namespace reset overreach, retained as adjacent reset-contract evidence.
- Redis Agent Memory Benchmark pinned adapter and runner: reset return is treated as clean precondition.
- Current Redis benchmark no-shrink reset unit test: stuck residual set is an accepted normal-return branch.

Direct-prior-art search found general benchmark isolation and cross-run contamination guidance, plus deletion/reset bugs. No located work performs the exact Agent Memory experiment of independently attesting clean state after reset and replaying benchmark outcomes under invoke-only versus verified-clean reset.

The novelty statement is search-bounded and remains medium-high risk.
