# Change History V22

- Upgraded C33 from source-integration-only evidence to a real provider reset-defect class.
- Added maintainer-confirmed local Qdrant reset resurrection from Mem0 #6411 / merged #6412.
- Confirmed current Mem0 main still carries the Valkey reset implementation described by #6995.
- Kept the reported ~3,400 stale documents / Recall@1=0.000 result outside frozen claims due conflicting provenance and missing raw artifact.
- Added provider-neutral Reset Attestation Protocol.
- Kept Formal Experiment locked pending real affected-backend paired outcome replay.
