# Reset Census V21

## Redis benchmark / Mem0

Reset surface: `Memory.delete_all(user_id=...)`.
Historical evidence: Mem0 v2.0.14 issue #6627 silently left rows beyond the first vector-store page for nine common stores. Fixed by PR #6636 on 2026-07-31.
Version note: Redis benchmark declares `mem0ai` without a version pin. Current installs resolve a fixed release; historical reproducibility therefore depends on recording the resolved dependency version.

## Redis benchmark / Redis Agent Memory

Reset surface: delete owner sessions, then repeatedly search and bulk-delete long-term memories.
Current code risk: if the search result set fails to shrink after a successful DELETE response, reset returns normally with residual state. Upstream unit test explicitly pins this behavior.
Real-service trigger: unverified. Redis docs confirm automatic extraction runs asynchronously in the background, which makes cleanup/extraction overlap a relevant condition to test, but no claim is made that the hosted service reproduces the mocked no-shrink branch.

## Redis benchmark / Zep

Reset deletes the benchmark user. Current Zep docs state that deleting a user removes threads, artifacts, user graph and extracted knowledge. No user-data residual mechanism established in this V21 census. Project-level ontology/config remains outside the user deletion surface but is treated as configuration state rather than cross-run memory residue unless a benchmark mutates it.

## Redis benchmark / Bedrock AgentCore

The adapter lists/deletes events per session and separately paginates long-term memory records. AWS ListEvents is paginated, but the Python MemoryClient handles pagination internally up to the requested maximum, and this benchmark creates one event per session. No concrete residual mechanism established here.

## Redis benchmark / Vertex, Graphiti, Supermemory

Static inspection found explicit purge/clear/bulk-delete reset paths. No concrete current residual mechanism established in V21. They remain targets for dynamic attestation rather than supported failures.

## Census decision

C33 survives. It now has one historical provider defect and one current benchmark-level silent reset branch. Cross-provider prevalence remains unverified and is the next Gate.
