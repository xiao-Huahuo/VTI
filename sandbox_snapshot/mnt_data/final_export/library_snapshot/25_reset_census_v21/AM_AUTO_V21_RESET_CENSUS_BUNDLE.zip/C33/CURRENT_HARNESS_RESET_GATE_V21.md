# C33 Current Harness Reset Gate V21

Project: AM-AUTO-20260918-R1
Date: 2026-09-19

## Current benchmark finding

Pinned Redis Agent Memory Benchmark commit `94192c39e2a4a154f441a5411e3d73c4f54974a6` contains a current-code reset path that can return normally while long-term memories remain.

`RedisAgentMemoryStore._delete_memories()` searches all owner memories, sends a bulk DELETE, searches again, and returns when the memory-id set is unchanged from the previous iteration. The return carries no error or residual-state count.

The repository contains an explicit unit test named `test_redis_agent_memory_reset_stops_when_search_does_not_shrink`. Its mocked service returns one memory named `stuck` on every search and HTTP 200 with an empty `deleted` list on DELETE. The test expects `await store.reset()` to complete normally after two searches.

The LongMemEval runner interprets a normal reset return as a clean start and immediately ingests the next example.

## Deterministic runner-level replay

V21 models the exact tested control flow. Run A leaves a unique canary. Reset receives successful DELETE responses while the search set does not shrink, then returns. Run B ingestion proceeds. The Run-A canary remains visible in Run B.

Observed:

- reset returns normally: yes
- bulk-delete calls before silent stop: 1
- Run-A canary remains after reset: yes
- Run-A canary remains visible after Run-B ingestion: yes

This is current harness feasibility evidence. It does not establish that the hosted Redis service currently produces the no-shrink response pattern in ordinary operation.

## Consequence for C33

C33 no longer depends solely on the historical Mem0 2.0.14 defect. There are now two distinct reset-failure mechanisms:

1. provider reset implementation can silently leave rows behind;
2. benchmark reset implementation can intentionally stop and return success while residual state remains.

The remaining hard Gate is reality and impact: observe residual state on real provider runs or frozen public traces, then show a benchmark outcome change under verified-clean reset.
