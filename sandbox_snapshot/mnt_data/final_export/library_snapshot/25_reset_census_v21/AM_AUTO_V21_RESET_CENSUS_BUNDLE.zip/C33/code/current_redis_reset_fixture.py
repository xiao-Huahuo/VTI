import json
from pathlib import Path

class CurrentRedisResetModel:
    """Control-flow model of RedisAgentMemoryStore._delete_memories at pinned benchmark commit."""
    def __init__(self):
        self.memories = ["RUN-A-CANARY"]
        self.delete_calls = 0

    def search(self):
        return list(self.memories)

    def bulk_delete(self, ids):
        self.delete_calls += 1
        # Model the exact condition covered by the upstream unit test:
        # DELETE returns success but search state does not shrink.
        return {"deleted": []}

    def reset(self):
        previous = None
        for _ in range(10):
            items = self.search()
            if not items:
                return
            current = set(items)
            if previous is not None and current == previous:
                return
            previous = current
            self.bulk_delete(items)


def benchmark_two_case_flow():
    store = CurrentRedisResetModel()

    # End of Run A / start of Run B. Upstream runner treats normal return as success.
    store.reset()
    residual_after_reset = store.search()

    # Runner continues with Run B ingestion after reset returned.
    store.memories.append("RUN-B-FRESH")
    run_b_visible = store.search()

    out = {
        "scope": "current benchmark control-flow feasibility, mocked provider response",
        "upstream_test_condition": "DELETE 200 response with unchanged long-term-memory search set",
        "reset_returned_normally": True,
        "delete_calls": store.delete_calls,
        "residual_after_reset": residual_after_reset,
        "run_b_visible_state": run_b_visible,
        "run_a_canary_visible_in_run_b": "RUN-A-CANARY" in run_b_visible,
        "expected": {
            "delete_calls": 1,
            "run_a_canary_visible_in_run_b": True
        }
    }
    assert out["delete_calls"] == 1
    assert out["run_a_canary_visible_in_run_b"] is True
    return out

if __name__ == "__main__":
    out = benchmark_two_case_flow()
    p = Path(__file__).resolve().parents[1] / "results" / "current_redis_reset_fixture.json"
    p.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))
