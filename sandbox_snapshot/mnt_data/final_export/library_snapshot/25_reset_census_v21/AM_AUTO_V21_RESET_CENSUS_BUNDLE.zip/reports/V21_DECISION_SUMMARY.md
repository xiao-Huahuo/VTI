# V21 Decision Summary

C33 remains the sole primary provisional candidate and is materially stronger than V20.

V20 bound a historical provider defect to a benchmark reset call. V21 adds a current benchmark-level mechanism: the pinned Redis Agent Memory adapter deliberately stops deletion and returns normally when the post-delete long-term-memory search set does not shrink. The repository has a unit test that fixes this exact behavior. Since the runner proceeds after any normal reset return, a residual state can become the initial state of the next example without an error.

A deterministic runner-level fixture confirms the causal chain under the upstream-tested response pattern. This remains source-integration evidence, not a claim about current hosted Redis behavior.

The reset census did not manufacture additional failures: Zep user deletion has a strong current user-data deletion contract, Bedrock's SDK handles event pagination for the benchmark's one-event-per-session pattern, and no concrete residual mechanism was established for Vertex, Graphiti or Supermemory by static inspection.

Next hard Gate: real provider reset attestation or public raw trace evidence, then paired score replay comparing invoke-only reset with independently verified clean reset. Formal Experiment remains locked.
