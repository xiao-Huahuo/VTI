# V29 Handoff

Canonical root: `/Research/AgentMemory/AM-AUTO-20260918-R1`

Primary candidate: C33 — Trial-State Attestation for Agent-Memory Benchmarks

Status: `IDEA_VALIDATION_V29_C33_PUBLIC_CONTAMINATION_TRACE_FOUND_RUNTIME_PAIRING_STILL_PENDING`

## What changed from V28

V28 had two source-proved positive integrations (MemArena, Redis) but no direct observed benchmark contamination. V29 adds a third, independent benchmark with a committed stale retrieval trace:

`AlekseiMarchenko/agent-memory-benchmark@55d4f02d61388525105ffe34fe3f9d2c846d25bf`

Layer-1 `ma-03` under fixed scope `fix-agent` retrieves a near-verbatim memory from the fixed `fix-agent` seed in Layer-2 `l2-04`. The historical runner executes Layer 1 before Layer 2, so the retrieved Layer-2 memory must predate the current Layer-1 execution.

This proves observable stale-state retrieval in a public result artifact. Do not claim score causality from this trace alone.

## Strong negative control added

`OpenDataBox/MemoryData@bdbe698f776d921ac791d1b07c0a7fc65a8bb4bb`

Its Mem0 integration puts both Qdrant and `history.db` under each agent save folder, and `--force` deletes that folder before rebuild. `--retry_failed_queries` reruns search/answer only, not partial memorization. Treat as lifecycle-safe negative control for the current mechanism.

## Current evidence matrix

- MemArena / Mem0 OSS 2.0.11: positive source mechanism, paired outcome pending.
- Redis Agent Memory Benchmark / Mem0 OSS 2.0.19: positive source mechanism, paired outcome pending.
- Agent Memory Benchmark / Mem0 Cloud: positive observed stale retrieval trace, score causality pending.
- MemoryData / local Mem0: strong negative lifecycle control.
- ForgetEval / Mem0 infer=False: mechanism-negative control.

## Claim boundary

The novelty is not generic hermetic reset. The paper, if it survives runtime validation, is an empirical memory-benchmark audit plus executable trial-state attestation over behaviorally accessible provider state.

## Next action

Do not spend another cycle on generic literature search unless a direct memory-benchmark reset-attestation paper appears. Priority is runtime causality:

1. Redis paired retry probe.
2. MemArena paired replay.
3. AMB historical-v2 fixed-scope contamination replay.

For each, report representation -> retrieval -> answer -> score, without skipping directly to score.
