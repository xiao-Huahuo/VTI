# Novelty closure V29

## Prior-art boundary

General benchmark hermeticity is established prior art. Recent agent-evaluation work explicitly discusses clean initial state, environment reset, state leakage, and snapshot-diff style checks. Mem0 upstream also has prior reports involving stale message-history context.

Therefore C33 must not claim novelty for:

- the abstract statement that stateful benchmarks need resets;
- snapshot-diffing as a generic reset test;
- the existence of Mem0 stale `Last k Messages` behavior.

## Residual research contribution

The remaining defensible contribution is domain-specific and empirical:

1. model an agent-memory benchmark integration as a set of behaviorally accessible persistent state surfaces rather than one advertised memory store;
2. audit real benchmark adapters against that model;
3. show multiple distinct lifecycle failures in real integrations;
4. connect source-level mismatch to paired representation/retrieval/answer effects;
5. emit machine-checkable per-surface trial-state receipts;
6. compare against implementations whose lifecycle naturally captures all relevant state.

## Evidence status after V29

Positive source-proved:

- MemArena × Mem0 OSS 2.0.11: hidden message sidecar survives nominal namespace reset / separate Qdrant store.
- Redis Agent Memory Benchmark × Mem0 OSS 2.0.19: mid-ingest retry/resume can inherit stale message sidecar after scoped delete.

Positive observed trace:

- Agent Memory Benchmark × Mem0 Cloud: committed Layer-1 trace retrieves a near-verbatim fixed-scope Layer-2 fixture memory from prior state.

Negative controls:

- MemoryData × local Mem0: vector store and history DB are both trial-local under agent save folder; force rerun deletes the lifecycle root.
- ForgetEval × Mem0: `infer=False`, so the message-history extraction sidecar is not behaviorally active.
- MemArena Graphiti / Letta: current adapter reset paths are broader; no equal-grade mismatch established.

## Publication gate

C33 remains a paper candidate only if at least one source-proved mismatch produces a reproducible paired difference in representation or retrieval, and preferably downstream answer/score differences on more than isolated anecdotes.

If paired replay is practically null across MemArena and Redis, while the only observed effect remains the AMB historical trace, downscope to a benchmark audit / engineering note rather than a full research paper.
