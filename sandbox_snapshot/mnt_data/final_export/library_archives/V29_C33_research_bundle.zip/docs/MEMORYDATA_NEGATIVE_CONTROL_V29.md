# MemoryData as a lifecycle-isolation negative control

Frozen repository: `OpenDataBox/MemoryData@bdbe698f776d921ac791d1b07c0a7fc65a8bb4bb`

## Mem0 state placement

`utils/agent.py::_initialize_mem0_agent` explicitly binds Mem0 state to the per-context agent folder:

- `MEM0_DIR` defaults to `<agent_save_folder>/mem0_home`
- `history_db_path = <agent_save_folder>/mem0_runtime/history.db`
- Qdrant path = `<agent_save_folder>/mem0_runtime/qdrant`

The explicit `history_db_path` is the important part for the stale `Last k Messages` sidecar surface.

## Clean rerun semantics

`--force` is documented as a full-reset rerun. `initialize_and_memorize_agent(..., force_rebuild=True)` first resets supported external persistence and then recursively deletes `agent_save_folder` before constructing the agent again.

For local Mem0, both vector and message-history state live under that deleted folder. No separate scoped `Memory.delete_all(user_id=...)` is required to establish a clean local state.

## Retry semantics

`--retry_failed_queries` removes failed queries from the skip set but does not force agent rebuild. If the context has a reusable Mem0 source-map marker, the existing agent state is loaded.

This is appropriate because the Mem0 query path performs `memory.search(...)` and answer generation only. It does not call `Memory.add`. Failed query replay therefore does not restart a partially completed memorization transaction.

## Why this matters to C33

MemoryData demonstrates a concrete safe design pattern:

> Bind every behaviorally active local provider state surface to the same trial/context lifecycle directory, then replace that directory atomically for a clean rerun.

It is therefore a negative control against the claim that Mem0 itself necessarily makes benchmark isolation impossible. The defect is integration/lifecycle-specific.
