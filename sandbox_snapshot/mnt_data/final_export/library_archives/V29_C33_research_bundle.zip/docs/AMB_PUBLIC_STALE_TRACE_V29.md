# Agent Memory Benchmark public stale-state trace

## Frozen evidence

Repository: `AlekseiMarchenko/agent-memory-benchmark`
Historical result commit: `55d4f02d61388525105ffe34fe3f9d2c846d25bf`
Result generation timestamp: `2026-03-31T21:50:31.205Z`

Relevant files at the same commit:

- `src/runner.ts`
- `src/adapters/mem0.ts`
- `src/layer2/runner.ts`
- `src/categories/multi-agent.ts`
- `fixtures/layer2/cross-agent-handoff.json`
- `amb-results-mem0/results.json`

## Historical runner ordering

The v2.0.0 runner executes all requested Layer-1 categories first. Only after that loop does it call `runLayer2(...)` when `layer === "2" || layer === "all"`.

Therefore a Layer-1 retrieval cannot legitimately contain a memory first introduced by the Layer-2 phase of that same `--layer all` invocation.

## Scope mapping

Historical Mem0 adapter:

- store: `user_id = options?.agentId || "amb-benchmark"`
- search: `user_id = options?.agentId || "amb-benchmark"`

Layer-1 `ma-03`:

- seed is written under `debug-agent`
- query is issued under `fix-agent`

Layer-2 `l2-04` contains a fixed seed under `fix-agent`:

`Fix applied: increased connection pool to 100, added connection timeout of 5 seconds`

## Committed trace

The committed Layer-1 `ma-03` result retrieves:

`User applied a fix that increased the connection pool to 100 and added a connection timeout of 5 seconds`

with memory ID `c4dcc95f-5ead-49fa-80bf-cde6c51707b2` and `createdAt = 2026-03-31T14:38:49-07:00`.

Token-set Jaccard between the committed retrieved text and the Layer-2 seed is 0.692. More importantly, the distinctive tuple `connection pool -> 100 -> timeout 5 seconds` is shared exactly.

## Interpretation

This is strong evidence that a memory produced by an earlier execution of the fixed `fix-agent` Layer-2 fixture remained visible to a later Layer-1 `fix-agent` query.

The benchmark cleans IDs created during the current test/scenario and performs a final adapter cleanup, but it does not establish a clean precondition for stable explicit agent scopes at the start of a new benchmark run. A previous process interruption, failed deletion, adapter bookkeeping miss, or earlier version can therefore leave state that the next run inherits.

The evidence proves observable retrieval contamination. It does not, by itself, prove why the old memory survived, nor that the Layer-1 pass/fail would have changed under a verified-clean scope.

## Current-head relevance

At repository head `9146ffa044109166b5d61146ebbf1c89fa544608`, ordinary Layer-1 tests still use unique default IDs, but explicit multi-agent IDs such as `fix-agent` remain fixed and the benchmark still relies on deletion of IDs known to the current process rather than a pre-run clean-state attestation for those scopes. Thus the lifecycle hazard is not merely an artifact of the archived result file.
