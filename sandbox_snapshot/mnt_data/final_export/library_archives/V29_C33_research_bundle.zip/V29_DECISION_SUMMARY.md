# V29 Decision Summary — C33

Date: 2026-09-19

Status: IDEA_VALIDATION_V29_C33_PUBLIC_CONTAMINATION_TRACE_FOUND_RUNTIME_PAIRING_STILL_PENDING

## Decision

C33 remains the sole primary candidate, but the claim boundary is revised again.

The paper should not be framed as discovering reset hermeticity in general, nor as discovering Mem0 stale-message behavior. Those ideas already have prior art. The defensible contribution is a memory-benchmark-specific empirical audit of **trial-state cleanliness across behaviorally accessible state surfaces**, backed by real integrations, executable attestation, and paired outcome replay.

Working label: **Trial-State Attestation for Agent-Memory Benchmarks**.

## New V29 evidence

### 1. Public historical retrieval contamination in Agent Memory Benchmark × Mem0 Cloud

Frozen historical commit: `AlekseiMarchenko/agent-memory-benchmark@55d4f02d61388525105ffe34fe3f9d2c846d25bf`.

The committed `amb-results-mem0/results.json` was generated at `2026-03-31T21:50:31.205Z` and records, for Layer-1 test `ma-03 / ma-03-q1`, a retrieved memory:

> User applied a fix that increased the connection pool to 100 and added a connection timeout of 5 seconds

with `createdAt = 2026-03-31T14:38:49-07:00`.

At the same historical commit, `fixtures/layer2/cross-agent-handoff.json` contains the fixed `fix-agent` seed:

> Fix applied: increased connection pool to 100, added connection timeout of 5 seconds

The historical runner executes Layer 1 before Layer 2. Therefore the Layer-1 retrieval cannot have been produced by the Layer-2 phase of that same run. The Mem0 adapter maps `agentId` directly to Mem0 `user_id`, and both the Layer-1 query and the Layer-2 fixture use the fixed `fix-agent` scope.

This is direct evidence of a stale historical memory being behaviorally visible in a later benchmark trial. It is evidence of **retrieval contamination**, not yet evidence that the final benchmark score changed because of contamination.

### 2. Why AMB is a distinct failure surface

The AMB runner creates unique timestamped scopes for ordinary tests, but explicit multi-agent fixtures use stable IDs such as `debug-agent` and `fix-agent`. Cleanup deletes only IDs recorded during the current process. There is no pre-run purge or attestation for arbitrary state already present in those stable scopes. Thus a prior interrupted or imperfect cleanup can survive into a later run.

This differs from the MemArena and Redis cases:

- MemArena: repeated-run / separate-store reset leaves Mem0 local message sidecar outside the nominal Qdrant store.
- Redis Agent Memory Benchmark: mid-ingest retry / resume calls scoped `delete_all`, which leaves Mem0 message sidecar.
- AMB: stable benchmark-owned scope can inherit old hosted-provider state because cleanliness is assumed from previous cleanup rather than established as a precondition.

### 3. MemoryData is a strong design negative control

Frozen commit: `OpenDataBox/MemoryData@bdbe698f776d921ac791d1b07c0a7fc65a8bb4bb`.

For Mem0, MemoryData explicitly places both:

- `history_db_path` at `<agent_save_folder>/mem0_runtime/history.db`
- Qdrant path at `<agent_save_folder>/mem0_runtime/qdrant`

and `--force` removes the whole agent save folder before rebuild. Its `--retry_failed_queries` mode reuses the existing memorized state but only re-executes query/search; the Mem0 query path does not call `Memory.add`.

This is a useful negative control: the same underlying Mem0 state surfaces can be made trial-local by lifecycle design, without a bespoke reset call.

## Updated claim boundary

Defensible:

1. Agent-memory benchmark integrations can leave behaviorally accessible state outside the state they nominally reset or isolate.
2. The failure surfaces are not limited to one storage bug: they include hidden provider sidecars, retry/resume state, and stable benchmark scopes.
3. Public source and one committed retrieval trace already demonstrate that the risk can become observable benchmark behavior.
4. A benchmark can avoid the problem by binding all behaviorally active provider state to the trial lifecycle, as MemoryData does for local Mem0.

Not defensible yet:

1. Existing published benchmark scores are broadly invalid.
2. The AMB stale retrieval changed the reported score.
3. MemArena or Redis outcome metrics are affected until paired runtime replay is completed.
4. Trial isolation / reset hermeticity as a general systems principle is novel.

## Research decision

C33 is now stronger than at V28 because it has:

- two source-proved hidden-state positive integrations;
- one public historical retrieval-contamination trace from an independent benchmark;
- one strong implementation-level negative control;
- a narrowed novelty claim consistent with general hermeticity prior art.

The remaining bottleneck is empirical causality, not mechanism discovery.

## Next gate

Run paired clean-vs-native trials in this order:

1. Redis mid-ingest retry probe on Mem0 2.0.19.
2. MemArena LongMemEval-V1 paired replay on Mem0 2.0.11.
3. AMB fixed-scope replay with a pre-seeded old `fix-agent` memory versus verified-clean `fix-agent` scope, using the historical v2.0.0 harness.

Primary outcome hierarchy:

- representation difference;
- retrieval-set / rank difference;
- answer difference;
- benchmark score difference.

A representation/retrieval effect is already scientifically meaningful. Score-level claims require direct causal evidence.
