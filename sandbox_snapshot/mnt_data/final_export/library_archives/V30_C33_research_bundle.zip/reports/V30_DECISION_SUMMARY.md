# V30 Decision Summary — C33

Date: 2026-09-19

Status: `IDEA_VALIDATION_V30_C33_PUBLIC_TRACE_COUNTERFACTUAL_SCORE_NEUTRAL_RUNTIME_PAIRING_PENDING`

## Decision

C33 remains the sole primary candidate under the working label **Trial-State Attestation for Agent-Memory Benchmarks**.

V29 established a committed stale retrieval in Agent Memory Benchmark v2.0.0 × Mem0 Cloud. V30 closes the score-causality question for that exact public trace by replaying the frozen Layer-1 scoring rule under a narrow clean counterfactual that removes only the provenance-identified stale retrieval.

## V30 result

For `ma-03-q1`, the dirty public trace contains one stale `fix-agent` memory derived from the later `l2-04` fixture. The query expects `race condition` and `queue`. The stale result contains neither term, yielding score 0. Removing the stale result leaves an empty retrieval set, which also yields score 0.

The exact observed contamination event therefore changes retrieval behavior while leaving the frozen benchmark score unchanged:

- query retrieval count: 1 → 0;
- query score: 0 → 0;
- multi-agent category: 1/6 → 1/6;
- overall reported score: 7 → 7;
- query estimated tokens: 30 → 4;
- run-level estimated tokens: 1276 → 1250.

Layer 1 contains no separate answer-generation stage. Its score is computed directly from retrieved contents.

## Consequence for the claim ladder

The AMB public artifact now supports a stronger but narrower statement: behaviorally accessible stale provider state can enter a later benchmark trial and alter its retrieval output. For the one committed stale trace recovered here, the scoring effect is exactly zero under the frozen scoring function.

This result removes a source of overclaiming. The paper can use AMB as direct observational evidence of retrieval contamination, while score-distortion claims remain tied to future paired runtime evidence from Redis and MemArena.

## Runtime gate

The current execution environment contains neither Mem0 nor Qdrant client packages and exposes no Mem0/OpenAI provider credential for an exact `infer=True` replay. V30 therefore advances all provider-free causal analysis and freezes the next runtime order:

1. Redis Agent Memory Benchmark × Mem0 2.0.19 mid-ingest retry replay, native reset versus independently verified clean state.
2. MemArena × Mem0 2.0.11 LongMemEval-V1 repeated-run sidecar replay.
3. AMB v2.0.0 fixed-scope preseeded replay as a secondary reproducibility confirmation.

For every runtime arm, preserve representation, retrieval, answer where the benchmark has an answer stage, and score as separate outcomes.

Formal Experiment remains `NOT_STARTED`. The project stays in late idea validation until at least one real paired runtime replay establishes downstream effect or a principled null result.
