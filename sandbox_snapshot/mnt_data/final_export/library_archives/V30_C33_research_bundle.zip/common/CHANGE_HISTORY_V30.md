# V30 Change History

Date: 2026-09-19
Project: AM-AUTO-20260918-R1
Candidate: C33

1. Continued from V29 public stale-trace evidence without reopening generic novelty search.
2. Re-froze AMB v2.0.0 at commit `55d4f02d61388525105ffe34fe3f9d2c846d25bf` and re-read the runner, multi-agent tests, Mem0 adapter, scoring rule, category weights, Layer-2 runner, `l2-04` fixture, and committed Mem0 results.
3. Verified that the historical `ma-03-q1` stale retrieval is derived from the fixed `fix-agent` `l2-04` seed while Layer 1 executes before Layer 2.
4. Scanned committed Layer-1 retrievals against all five Layer-2 fixtures. Exactly one high-confidence later-fixture provenance hit was found at the frozen threshold: `ma-03-q1` → `l2-04`.
5. Implemented an offline counterfactual auditor using the benchmark's own Layer-1 keyword scoring and token estimator.
6. Removed only the provenance-identified stale result. Retrieval changed from one result to zero, while `ma-03-q1` remained 0, multi-agent remained 1/6, and overall reported score remained 7.
7. The query token proxy fell from 30 to 4, reducing the run-level estimated token total from 1276 to 1250 under the one-trace counterfactual.
8. Recorded Layer-1 answer generation as structurally inapplicable because Layer-1 scoring operates directly on retrieval contents.
9. Runtime audit confirms the current environment lacks Mem0, Qdrant client, and provider credentials. Real Redis/MemArena paired replay remains the next hard gate.
10. Advanced project state to `IDEA_VALIDATION_V30_C33_PUBLIC_TRACE_COUNTERFACTUAL_SCORE_NEUTRAL_RUNTIME_PAIRING_PENDING`.
