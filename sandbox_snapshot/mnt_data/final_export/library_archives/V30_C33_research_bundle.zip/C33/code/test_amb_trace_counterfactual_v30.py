#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import json

HERE = Path(__file__).resolve().parent
MOD_PATH = HERE / "amb_trace_counterfactual_v30.py"
FIXTURE = HERE.parent / "fixtures" / "amb_ma03_minimal_v30.json"

spec = importlib.util.spec_from_file_location("auditmod", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)

data = json.loads(FIXTURE.read_text(encoding="utf-8"))
r = mod.audit(data)

assert r["dirty"]["retrieval_count"] == 1
assert r["verified_clean_counterfactual"]["retrieval_count"] == 0
assert r["dirty"]["score"] == 0
assert r["verified_clean_counterfactual"]["score"] == 0
assert r["dirty"]["estimated_tokens"] == 30
assert r["verified_clean_counterfactual"]["estimated_tokens"] == 4
assert r["delta"]["query_estimated_tokens"] == -26
assert r["category_counterfactual"]["clean_score"] == r["category_counterfactual"]["recorded_score"]
assert r["benchmark_counterfactual"]["clean_overall_score"] == 7
assert r["benchmark_counterfactual"]["clean_total_estimated_tokens"] == 1250
assert r["answer_stage"]["status"] == "NOT_APPLICABLE_LAYER1"
print("11 assertions passed")
