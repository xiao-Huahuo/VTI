# C19 Kill Memo: Endogenous Exposure Bias / Memory Value Lock-In

## Decision
`KILLED_BY_PRIOR_ART_AND_INCREMENTAL_EXTENSION`

## Candidate claim
Memory 被检索后才获得结果反馈，结果反馈又改变后续检索概率，可能产生自强化 value lock-in；通过探索或因果/OPE 校正可缓解。

## Fatal prior art
1. **When to Forget: A Memory Governance Primitive** 已显式运行 Retrieval Policy Feedback Loop，采用基于 Memory Worth 的 softmax retrieval，并检查不同探索率；作者同时列出 non-stationary utility、sparse specialist memories、adversarial skew 等未测边界。
2. **Hindsight Memory-PRM** 通过 deletion-and-reanswer intervention 对 memory entry 做 intervention-calibrated credit。
3. **Feedback-Normalized Developer Memory for RL Coding Agents** 已记录 contextual memory selection propensity 并使用 shadow contextual bandit / OPE gates。
4. **Causal Intervention-Based Memory Selection** 已直接使用 causal intervention 研究 memory selection。

## Reason for kill
宽泛的“反馈环导致选择偏差，再用 exploration/OPE/causal credit 修正”已经被直接覆盖。把场景换成 non-stationary 或 sparse-specialist 更接近已有工作的 future-work extension，缺少独立机制命题。

## Reusable residue
保留一个可复用 benchmark 子问题：在 non-stationary + sparse-specialist memory 分布下，现有 Memory Worth feedback loop 是否出现 collapse。该子问题暂不作为独立论文主线。
