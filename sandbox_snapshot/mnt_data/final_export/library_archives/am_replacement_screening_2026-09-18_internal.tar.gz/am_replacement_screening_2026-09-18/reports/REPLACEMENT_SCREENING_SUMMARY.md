# Replacement Screening Summary

## Outcome
C19 and C22 are killed. C20 and C21 survive replacement screening. Together with previously pivoted C16, the active research pool becomes C16/C20/C21.

## C20 evidence
A calibrated synthetic stress test anchored to published DriftJudge rubric-level shifts/correlations produces stable certificate-fork signal. This validates measurability only. Real item-level verifier outputs remain required before H1 is considered supported.

## C21 evidence
Official InMind 125-task data were parsed directly from the public GitHub repository. Raw memory-to-indirect-query TF-IDF R@5 is 7.2%. On the 77 structured-bridge tasks, a gold-derived bridge representation yields R@5 85.7%. The oracle result is prohibited as method evidence; it establishes that bridge-aware representation can separate targets if such cues can be generated without gold leakage.

## Portfolio logic
- C16: single-agent/persistent certificate over time.
- C20: same certificate semantics across heterogeneous shared-memory consumers.
- C21: orthogonal retrieval/routing problem caused by implicit world-knowledge bridges.

C16 and C20 share verification infrastructure but answer different scientific questions. C21 diversifies the portfolio away from trust/governance.
