# Red-Team V3

## C16
Main attack: generic judge drift + BAVAR version registry already cover the story. Survives only if persistent memory lifecycle/action flip is independently measured.

## C20
Main attack: a canonical verifier trivially removes forks. The paper must demonstrate legitimate heterogeneous policy domains where canonicalization is undesirable or costly, and must measure action-sensitive forks rather than score disagreement.

## C21
Main attack: InMind itself invites routing, making an obvious router potentially incremental. The proposed mechanism must outperform LRE/EPC/ProactAgent/query expansion under matched tokens and avoid benchmark-gold leakage. Over-warning is a first-class failure metric.

## Portfolio-level attack
C16 and C20 may collapse into one paper if both ultimately reduce to version-scoped certificates. Keep separate until real pilots show C20 has multi-agent coordination effects that C16 cannot express.
