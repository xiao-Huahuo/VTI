# C20 Idea Card: Shared Trust Fork

Working title: **Same Memory, Different Trust: Certificate Forks in Heterogeneous Multi-Agent Memory**

## Problem
共享 memory 系统通常把内容和部分 trust/confidence metadata 视为公共状态。然而不同消费者可能运行不同 verifier 模型、prompt、policy、calibration 或风险阈值。同一份 immutable memory 对 Agent A 可处于 ACTIVE，对 Agent B 可处于 QUARANTINE 或 REVERIFY。若系统只保存单一 global trust label，消费者语义会被压平。

## Observed gap
现有 shared-memory 工作已经覆盖 scope、provenance、stale propagation、contradiction、peer reliability 和 heterogeneous memory transfer。本轮检索尚未发现专门测量“同一 memory artifact 在异构 consumer verifier/policy 下产生 trust/lifecycle fork，并进一步引起协调动作分叉”的 benchmark。

## Core estimand
在相同 content + provenance 下，仅改变 consumer verifier/policy：
1. certificate fork rate
2. lifecycle fork rate
3. coordination/action fork rate
4. global-certificate reuse error

## Candidate mechanism
不是强制消灭所有分歧，而是把 certificate 明确绑定到 `consumer trust domain + verifier version + policy version`；共享的是 evidence/content，trust standing 是 scoped derived state。对需要全局一致授权的动作再引入 canonical verifier 或 explicit reconciliation。

## H1
真实可接受的 verifier/policy heterogeneity 会让相同 memory 产生非平凡 certificate fork。

## H2
一部分 certificate fork 会跨越 lifecycle boundary，改变 retrieval eligibility、conflict handling 或 action authorization。

## H3
单一 global trust label 在异构 fleet 中会产生可测量的 false reuse / false suppression；scoped certificate 能减少这类语义错配。

## Killer conditions
- 真实异构 verifier/policy 下 fork rate 很低。
- fork 大多停留在分数层，不改变 lifecycle/action。
- 所有合理 fleet 都能低成本采用一个 canonical verifier/policy，此时问题退化为配置统一。
- 出现直接 benchmark/system 已完整研究 per-consumer certificate fork。
