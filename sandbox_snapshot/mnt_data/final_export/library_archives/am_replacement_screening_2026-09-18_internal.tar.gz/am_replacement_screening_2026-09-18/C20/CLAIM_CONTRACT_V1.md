# C20 Claim Contract V1

H1: 固定 content/provenance 后，仅改变 consumer verifier/policy 即可产生非平凡 certificate fork。

H2: certificate fork 中存在跨越 ACTIVE/QUARANTINE/REVERIFY 等治理边界的子集。

H3: global trust label 相比 scoped certificate 在相同 evidence 下产生更多 false reuse / false suppression。

必须报告：fork rate、lifecycle fork、action fork、canonical-verifier baseline、full-local-recertification cost。

KILL: 真实 fork < 5% 且 action-sensitive fork < 1%，或 canonical verifier 几乎无代价地消除问题。
