# C20 Red-Team Review

P0 风险是“配置不一致而已”。论文必须证明异构 policy/verifier 是合法 fleet requirement，而非运维失误。

最强反例基线：单一 canonical verifier。如果其成本和治理代价可接受，fork 问题可以被架构统一直接消除。

P1 风险：score disagreement 不等于 lifecycle/action fork。主论文只接受跨治理边界的 effect。

P1 风险：不同 agent 本来就允许不同 risk policy。论文目标是保留语义分叉并防止 global-label 误用，而不是把所有分叉当故障。
