# C20 Calibrated Feasibility Result

使用 C16 保存的 DriftJudge published rubric-level mean shift / correlation 对合成 score pair 做校准压力测试。该实验不是 item-level real-data reproduction。

50,000 synthetic certificates / rubric，固定随机种子 20260918：

| consumer policy | mean certificate fork | range | global V1 mismatch |
|---|---:|---:|---:|
| same threshold | 19.66% | 12.79%–33.00% | 11.10% |
| heterogeneous threshold | 22.43% | 15.46%–30.55% | 19.40% |
| wide policy gap | 32.06% | 25.33%–38.68% | 31.02% |

解释：真实 judge drift 的量级足以让一个 scoped-trust benchmark 具有可测信号。这里没有证明真实 memory fleet 的 fork rate，也没有证明 scoped certificate 方法优于 canonical verifier。

下一 Gate：获取 item-level frozen judge outputs 或直接运行两组 frozen verifier，对同一批 memory items 生成真实 certificate fork census。
