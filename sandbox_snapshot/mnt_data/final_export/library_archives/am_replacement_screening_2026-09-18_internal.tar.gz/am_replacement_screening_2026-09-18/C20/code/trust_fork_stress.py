"""C20 feasibility stress test.
Synthetic only. Parameters are calibrated to published DriftJudge rubric-level
mean shifts/correlations, but this is not an item-level reproduction.
"""
import csv, json, math
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
SRC=Path('/mnt/data/am_real_evidence_gate_2026-09-18/C16/PUBLISHED_REAL_DRIFT_TABLE.csv')
OUT=HERE.parent/'results'/'c20_trust_fork_stress.json'
rng=np.random.default_rng(20260918)
rows=list(csv.DictReader(SRC.open()))

def sigmoid(x): return 1/(1+np.exp(-x))
results=[]
for r in rows:
    rho=float(r['correlation']); shift=float(r['mean_shift'])
    n=50000
    z1=rng.normal(size=n)
    z2=rho*z1+math.sqrt(max(1e-8,1-rho*rho))*rng.normal(size=n)
    # Map latent score to [0,1]; shift is applied conservatively at 0.5 scale.
    s1=sigmoid(z1)
    s2=np.clip(sigmoid(z2)+0.5*shift,0,1)
    for ta,tb,label in [(0.60,0.60,'same_policy'),(0.60,0.70,'heterogeneous_policy'),(0.55,0.75,'wide_policy_gap')]:
        a=s1>=ta; b=s2>=tb
        fork=float(np.mean(a!=b))
        both_active=float(np.mean(a & b))
        both_inactive=float(np.mean(~a & ~b))
        # A downstream coordination action requires both agents to authorize use.
        # A global V1 certificate causes unsafe/incorrect reuse whenever A says active and B says inactive.
        global_v1_mismatch=float(np.mean(a & ~b))
        results.append({
            'dataset':r['dataset'],'rubric':r['rubric'],'change_type':r['change_type'],
            'rho':rho,'published_mean_shift':shift,'policy':label,
            'threshold_a':ta,'threshold_b':tb,'certificate_fork_rate':fork,
            'both_active':both_active,'both_inactive':both_inactive,
            'global_v1_mismatch_rate':global_v1_mismatch
        })
summary={}
for policy in ['same_policy','heterogeneous_policy','wide_policy_gap']:
    xs=[x for x in results if x['policy']==policy]
    summary[policy]={
        'mean_fork_rate':float(np.mean([x['certificate_fork_rate'] for x in xs])),
        'min_fork_rate':float(np.min([x['certificate_fork_rate'] for x in xs])),
        'max_fork_rate':float(np.max([x['certificate_fork_rate'] for x in xs])),
        'mean_global_v1_mismatch':float(np.mean([x['global_v1_mismatch_rate'] for x in xs]))
    }
OUT.write_text(json.dumps({'status':'SYNTHETIC_CALIBRATED_FEASIBILITY_ONLY','seed':20260918,'summary':summary,'rows':results},indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
