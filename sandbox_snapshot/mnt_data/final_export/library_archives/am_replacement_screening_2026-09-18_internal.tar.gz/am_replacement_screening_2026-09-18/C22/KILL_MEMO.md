# C22 Kill Memo: Semantic Replica Divergence / Consistency Amplification

## Decision
`KILLED_BY_FORMAL_SEPARATION_RISK`

## Candidate claim
分布式共享 memory 的 replica/index visibility lag 会被语义检索放大成 top-k divergence，随后形成 tool/action divergence；存储最终收敛后，已经执行的外部动作仍不可逆。

## Prior-art pressure
- **Governed Shared Memory for Multi-Agent LLM Systems** 已把 stale propagation、cross-agent visibility、strong-write write-to-visible latency 纳入生产实测。
- **PlanFence** 已研究 shared state 更新后 stale plan 导致的外部 invalid action，并用 dependency-scoped validation 阻止执行。
- 生产向量索引文档已经明确 eventual-consistency/read-after-write lag 会造成 agent recall miss，强一致性或写后直读属于常规工程解法。

## Formal separation failure
当前候选仍可被“标准分布式 stale read + semantic index + action consumer”直接组合表达。尚未找到一个必须依赖 Agent Memory 特有机制、且强一致性/causal barrier 无法作为简单结构基线解决的独立 estimand。

## Reusable residue
保留 `memory-state divergence → top-k divergence → action divergence` 三层测量链，可作为未来 shared-memory systems benchmark 的一个 stress dimension，而不作为当前论文主贡献。
