# Novelty Freeze V4

Cutoff: 2026-09-18 Asia/Taipei

## Surviving claims

### C16
Novelty claim excludes verifier versioning itself and generic judge drift. Claim is measurement of persistent verifier-certificate drift crossing memory lifecycle/action boundaries.

### C20
Novelty claim excludes generic shared-memory trust/governance. Claim is consumer-specific certificate/lifecycle/action fork for identical shared artifacts under heterogeneous verifier/policy versions.

### C21
Novelty claim excludes discovering the InMind blind spot and generic proactive retrieval. Claim is a bridge-aware applicability representation/routing mechanism evaluated under matched budget on InMind, with gold bridge annotations used only as oracle ceiling.

## Explicitly killed in this refresh
C19, C22. C15 and C17 remain killed from Real Evidence Gate V3.
