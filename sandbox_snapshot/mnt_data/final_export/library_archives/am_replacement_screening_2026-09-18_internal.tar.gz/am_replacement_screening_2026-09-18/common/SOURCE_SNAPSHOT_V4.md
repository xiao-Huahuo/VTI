# Source Snapshot V4

Key current sources retained for replacement screening:

- Keep It InMind: Benchmarking the Implicit-Association Blind Spot in Agent Memory, arXiv:2607.24368, official repo `imlrz/InMind`, dataset SHA-256 `4e27c56047d1f7c3eaf21ad5b6662f638f81a434034546be08b85e09876675a4`.
- Learning What Not to Forget: Long-Horizon Agent Memory from a Few Kilobytes of Learning, arXiv:2606.20954.
- WhenLoss: Diagnosing Write and Retrieval Bottlenecks in Long-Context Memory Systems, arXiv:2605.24579.
- Ask Only When Needed: Proactive Retrieval from Memory and Skills for Experience-Driven Lifelong Agents, arXiv:2604.20572.
- Governed Shared Memory for Multi-Agent LLM Systems, arXiv:2606.24535.
- Σ-Mem: An Online Reliability Memory for LLM-based Multi-Agent Systems, arXiv:2607.27958.
- MemCollab, heterogeneous collaborative memory prior art.
- Hermes Agent issue #4726, engineering evidence of multi-profile shared trust/feedback interference.
- Fresh Memory, Stale Plans / PlanFence, arXiv:2609.03340.
