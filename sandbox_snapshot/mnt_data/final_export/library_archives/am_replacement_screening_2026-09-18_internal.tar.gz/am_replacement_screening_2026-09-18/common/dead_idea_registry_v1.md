# Dead Idea Registry

## C01 Counterfactual Memory Utility
Kill stage: Prior-Art Audit  
Reason: 因果图、反事实干预、决策效用驱动的 memory selection 已有多个 2026 工作。宽泛 claim 无独立性。  
Reusable lesson: 后续如果使用 causal signal，只能作为子机制，不能作为主创新。

## C02 Prospective Intention Memory
Kill stage: Prior-Art Audit  
Reason: PM-Bench、TriggerBench、Typed Intention Store 已从 benchmark 到结构化存储覆盖该问题。  
Reusable lesson: “未来触发式记忆”已经是独立子领域。

## C03 Dead-End Research Memory
Kill stage: Prior-Art Audit  
Reason: Persistent AI scientist fleet 已明确维护 dead-end registry，并在新研究前查询失败假设。  
Reusable lesson: 可作为科研 Agent 基础设施，不作为论文主 Idea。

## C04 Anti-Fixation Memory
Kill stage: Prior-Art Audit  
Reason: experience-following、MemTrapBench 已直接定义和测量 memory-induced reasoning fixation。  
Reusable lesson: fixation 可作为 C15-C17 的风险指标之一。

## C05 Context-Scope Memory
Kill stage: Prior-Art Audit  
Reason: Contextual Intent 和 scoped shared memory 已覆盖记忆作用域匹配问题。

## C06 Uncertainty-Preserving Memory
Kill stage: Prior-Art Audit  
Reason: BeliefMem 与 MemGuard 已把 belief probability、confidence、uncertainty 写入持久记忆。

## C07 Active Environment Revalidation
Kill stage: Prior-Art Audit  
Reason: 近期 environment-probing memory curation 已直接利用环境探测进行记忆校验。

## C08 Transitive Memory Rollback
Kill stage: Prior-Art Audit  
Reason: dependency-guided rollback、ChronoMem 等覆盖时间依赖与回滚传播。

## C09 Provenance/Authority Promotion Guard
Kill stage: Prior-Art Audit  
Reason: TMA-NM、provenance laundering、endogenous authorization laundering、Authority Collapse 已密集覆盖。

## C10 Model-Upgrade Memory Migration
Kill stage: Prior-Art Audit  
Reason: 2026-09 已出现专门研究 agent memory 在模型升级中的迁移可靠性。

## C11 Delayed Memory Credit Assignment
Kill stage: Prior-Art Audit  
Reason: Memory-R2、HiMPO、TreeMem 等正在直接研究 memory credit assignment。

## C12 Procedural Skill Repair under Tool Drift
Kill stage: Prior-Art Audit  
Reason: ProcMEM、ReMe、SkillRevise、environment probing 等相互邻近，直接切入创新风险高。

## C13 Multi-Source Conflict Fusion
Kill stage: Prior-Art Audit  
Reason: 多来源冲突与 memory fusion 已有明显工作簇。

## C14 Evolving Policy Memory
Kill stage: Prior-Art Audit  
Reason: PolicyBank 已研究从反馈持续形成和更新 policy understanding，外围 governance 工作也密集。

## C18 Policy-Epoch Memory Reauthorization
Status: RESERVE  
Reason: 与 governance architecture、policy versioning、authority provenance 的边界较近。问题尚有空间，但新颖性风险高于 C15-C17。
