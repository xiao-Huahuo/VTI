# Prior-Art Matrix V4

## C16 Persistent Certificate Drift

| Neighbor | Covered | Remaining gap |
|---|---|---|
| MemGuard | persistent verifier-derived metadata | verifier migration 后 metadata 的 semantic/lifecycle impact |
| DriftJudge | real judge/version/prompt drift attribution | drift 写入长期 memory 后的 lifecycle/action consequence |
| BAVAR | verifier registry/versioned judgments | 缺少 persistent certificate drift benchmark 与 downstream fork census |

Verdict: `SURVIVE_WITH_NARROW_MEASUREMENT_CLAIM`

## C20 Shared Trust Fork

| Neighbor | Covered | Remaining gap |
|---|---|---|
| Governed Shared Memory | scope, supersession, provenance, propagation | heterogeneous consumer verifier/policy 对同一 artifact 的 trust standing fork |
| GateMem | multi-principal access/forgetting governance | certificate/lifecycle/action fork |
| MemCollab | heterogeneous agent memory transfer | per-consumer trust semantics |
| Σ-Mem | peer reliability | trust of memory artifact under heterogeneous consumer policies |
| Hermes multi-profile issue | real engineering report: shared trust/feedback becomes muddied across roles/models | 未形成 controlled academic benchmark |

Verdict: `SURVIVE_PHENOMENON_FIRST`

## C21 Applicability-Sketch Routing

| Neighbor | Covered | Remaining gap |
|---|---|---|
| InMind | diagnoses implicit-association blind spot, explicitly leaves routing open | deployable routing mechanism |
| LRE | query-blind retention/eviction | no world-knowledge applicability sketch / InMind result |
| WhenLoss/EPC | anticipated future questions at write time | predicted queries are not reusable applicability predicates; InMind comparison absent |
| ProactAgent | learns when/what to retrieve during interaction | query-time/interaction retrieval, not precompiled implicit bridge cues |
| Prospective memory / ENPMR | delayed intention or domain-specific proactive retrieval | general user-fact implicit association across ten domains |

Verdict: `SURVIVE_REAL_BENCHMARK_READY`

## C19 / C22
Both killed; see individual Kill Memos.
