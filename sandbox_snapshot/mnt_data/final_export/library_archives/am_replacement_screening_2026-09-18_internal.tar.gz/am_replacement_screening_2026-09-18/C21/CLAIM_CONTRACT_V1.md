# C21 Claim Contract V1

H1: 不使用 gold bridge 时，learned/LLM-compiled applicability sketch 在 InMind target recall 上显著高于 raw-memory retrieval。

H2: 在相同 retrieval/context token budget 下，提升高于 generic query expansion、LRE-like retention 与 EPC-like predicted-query cues。

H3: false activation / over-warning 可控，end-to-end application 同步提升。

Gold `entity_1/entity_2/relation` 只允许作为 oracle ceiling，不得进入 proposed method 输入。

KILL: proposed 方法离开 gold annotation 后 R@5 提升 < 10pp，或 application accuracy 无提升，或 matched-token query expansion 等价。
