# C21 Idea Card: Applicability-Sketch Routing for Implicit Association

Working title: **Remember Before It Looks Relevant: Applicability-Sketch Routing for Implicit-Association Memory**

## Problem
InMind 证明 query-conditioned retrieval 对 world-knowledge-mediated relevance 存在结构性 blind spot。目标 memory 与查询文本可以几乎没有直接相似度，导致事实“能直接回忆，却在真正需要时没有进入 context”。

## Mechanism
写入或离线 consolidation 阶段，把 memory 编译为可审计 `applicability sketch`：
- preserved fact / subject state
- latent applicability concepts
- trigger entities/actions/situations
- consequence class
- provenance to raw memory

查询阶段先用 query 匹配 applicability sketch，再回到原始 memory 取证。关键点是把 world-knowledge bridge 的一部分计算提前，而不是用查询与原始 memory 直接相似。

## H1
在 InMind 间接查询中，sketch routing 能显著提高 target recall，同时直接查询性能不下降。

## H2
提升来自 bridge-aware cues，而非单纯增加 token、生成更多 query expansion 或永久展示更多 memory。

## H3
在固定 active-memory / retrieval token budget 下，sketch 能逼近 always-visible diagnostic 的一部分收益，并保持可控 false activation。

## Killer experiment
官方 InMind 125 tasks，固定背景和 injection protocol。对比官方六类 memory baseline、LRE-like query-blind retention、EPC-like anticipated-query write policy、ProactAgent-like proactive retrieval、raw-memory query expansion、all-visible diagnostic、gold bridge oracle。

## Kill conditions
- matched-token query expansion 达到相同效果。
- sketch 只有使用 benchmark gold relation/entity_2 才有效。
- false activation 导致 end-to-end application 不增反降。
- LRE/EPC/ProactAgent 或近期工作在 InMind 上已解决同一 routing problem。
