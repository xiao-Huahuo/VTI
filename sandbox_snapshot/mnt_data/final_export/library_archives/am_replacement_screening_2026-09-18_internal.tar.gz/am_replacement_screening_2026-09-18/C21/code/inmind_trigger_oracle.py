"""Reproduce the C21 structural diagnostic on the official InMind JSONL.
No model call is used. The bridge condition is an oracle ceiling and must never
be reported as a deployable method result.
Usage: python inmind_trigger_oracle.py /path/to/inmind.jsonl
"""
import json, math, re, sys
from collections import Counter
from pathlib import Path

STOP=set('a an the and or but if then to of in on for with is are was were be been being i you my me we our your it this that do does did have has had can could should would any some about from at as into when what how which who why lately want get make good recommendations recently now just really out up not no'.split())
def toks(s): return [x for x in re.findall(r'[a-z0-9]+',(s or '').lower()) if len(x)>1 and x not in STOP]
def ranks(rows,texts):
    docs=[toks(x) for x in texts]; n=len(docs); df=Counter()
    for d in docs: df.update(set(d))
    def vec(text):
        tf=Counter(toks(text)); v={}; norm=0
        for w,c in tf.items():
            x=(1+math.log(c))*(math.log((n+1)/(df[w]+1))+1);v[w]=x;norm+=x*x
        norm=math.sqrt(norm) or 1
        return {w:x/norm for w,x in v.items()}
    dv=[vec(x) for x in texts]; out=[]
    for i,r in enumerate(rows):
        q=vec(r['query'])
        sc=[(sum(q.get(w,0)*x for w,x in d.items()),j) for j,d in enumerate(dv)]
        sc.sort(key=lambda z:(-z[0],z[1]));out.append(next(k+1 for k,(_,j) in enumerate(sc) if j==i))
    return out
def stats(rs):
    return {'n':len(rs),'R1':sum(x<=1 for x in rs)/len(rs),'R5':sum(x<=5 for x in rs)/len(rs),'R10':sum(x<=10 for x in rs)/len(rs),'MRR':sum(1/x for x in rs)/len(rs),'median_rank':sorted(rs)[len(rs)//2]}
path=Path(sys.argv[1]); rows=[json.loads(x) for x in path.read_text().splitlines() if x.strip()]
structured=[r for r in rows if r.get('entity_1') and r.get('entity_2') and r.get('relation')]
out={'all_raw':stats(ranks(rows,[r['user_message'] for r in rows])),
     'structured_raw':stats(ranks(structured,[r['user_message'] for r in structured])),
     'structured_gold_bridge_oracle':stats(ranks(structured,[f"{r['entity_1']} {r['entity_2']} {r['relation']}" for r in structured]))}
print(json.dumps(out,indent=2))
