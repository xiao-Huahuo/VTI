# C21 Initial Review

## Status
`SURVIVE_REPLACEMENT_SCREENING / REAL_BENCHMARK_READY`

## Direct precursor
**Keep It InMind** 明确把 routing 作为开放问题：需要决定哪些 facts 在未来 query 尚未知时保持 visible。论文报告 in-context application 84.0%，现有 memory systems 间接查询最高约 14.4%，并发布 125-task benchmark。

## Strong adjacent work
- LRE：query-blind learned retention/eviction，目标是保留 task-critical history。
- WhenLoss/EPC：写入时生成 likely future questions，优化 predictive compression。
- ProactAgent：把何时/检索什么作为 learned action。
- Prospective-memory work：未来 cue/intention trigger，任务语义更偏 delayed intention。
- ENPMR：情绪支持领域的 proactive memory retrieval。

## Remaining distinction
C21 仅研究 **implicit-association retrieval**：目标事实本身已完整保存，失败来自 relevance bridge 隐含在 world knowledge 中。机制显式生成/维护 applicability cues，并在官方 InMind 上与以上类别 baseline 做 matched-budget 比较。
