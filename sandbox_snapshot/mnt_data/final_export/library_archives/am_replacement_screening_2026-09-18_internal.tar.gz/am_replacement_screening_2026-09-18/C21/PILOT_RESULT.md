# C21 Source-Backed Structural Diagnostic

来源：官方 `imlrz/InMind`，commit `5a2ab2686d3d5b832575f0288d41ecc93eab358b`。
数据文件 SHA-256：`4e27c56047d1f7c3eaf21ad5b6662f638f81a434034546be08b85e09876675a4`。

在全部 125 tasks 上，用相同简单 TF-IDF ranking：
- raw memory → indirect query：R@1 2.4%，R@5 7.2%，R@10 11.2%，median rank 58。

在 77 条具有结构化 entity/relation bridge 的任务上：
- raw memory → indirect query：R@5 6.49%，median rank 39。
- **gold bridge trigger oracle** → indirect query：R@1 77.92%，R@5 85.71%，R@10 87.01%，median rank 1。

该 oracle 使用 benchmark gold `entity_1/entity_2/relation`，严禁当作方法结果。它只证明：如果能在写入阶段从 memory 与世界知识生成足够好的 applicability cues，目标检索在该 benchmark 上存在很大的可分空间。

真正的下一 Gate：只给 compiler 原始 memory 与普通模型世界知识，完全隐藏 gold bridge，再跑官方评测。
