# C21 Red-Team Review

P0: InMind 本身已经把 routing 定义为开放问题。仅实现一个 obvious router 的创新度可能不足。必须给出机制上的独立性与跨 benchmark/跨域证据。

P0: benchmark leakage。`entity_2/relation/explanation/knowledge_source` 均不能作为 proposed method 输入。

P1: EPC 已通过 self-questioning 在写入时预测未来问题；LRE 已做 query-blind retention。C21 必须证明 applicability sketch 不是 predicted-query list 的换名。

P1: 永久 visible 高风险事实可能造成 over-warning。必须报告 target recall 与 false activation/application quality，而非只追 recall。

P1: 如果 query expansion 用同样模型预算即可完成 world-knowledge bridge，write-time sketch 的系统价值会下降。
